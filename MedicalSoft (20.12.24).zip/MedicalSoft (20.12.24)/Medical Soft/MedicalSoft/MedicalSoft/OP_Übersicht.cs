﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class OP_Übersicht : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        OleDbDataReader dr = null;
        DataTable dt = new DataTable();

        public OP_Übersicht()
        {
            InitializeComponent();

            
        }

        private void OP_Übersicht_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }

            //füllen des datagrids
            fillDATAGRID();
        }

        void fillDATAGRID()
        {

            // OP DATUM , OP Dauer , P_Name, OP_Saal, OP, ID
            try
            {
                cmd.CommandText = "Select OP_ID, OP_Datum, OP_Dauer, P_Name, OPA_Bezeichnung, OPS_ID, OPS_Typ from Operation, Patient, OP_Art, OP_Saal WHERE OPA_ID = OP_OPA_ID and P_ID = OP_P_ID and OPS_ID = OP_OPS_ID";
                cmd.Connection = con;

                da.SelectCommand = cmd;
                dt.Clear();
                da.Fill(dt);

                dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderCell.Value = "OP_ID";
                dataGridView1.Columns[1].HeaderCell.Value = "OP Datum";
                dataGridView1.Columns[2].HeaderCell.Value = "OP Dauer min";
                dataGridView1.Columns[3].HeaderCell.Value = "Patient";
                dataGridView1.Columns[4].HeaderCell.Value = "OP Art";
                dataGridView1.Columns[5].HeaderCell.Value = "OP Saal";
                dataGridView1.Columns[6].HeaderCell.Value = "Saal Typ";


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            //ÜBERGANG ZUR ABRECHNUNG
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie links auf die ganze Zeile ");

            }
            else
            {
                try
                {
                    string OP_NR = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    string Pname = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

                    Form Abrechnung = new Abrechnung(System.Convert.ToInt32(OP_NR), Pname);
                    this.Hide();
                    Abrechnung.ShowDialog();



                }
                catch (Exception a)
                {

                    MessageBox.Show("Bitte klicken Sie einen bereits vorhandenen Datensatz aus.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = null;

            Form HP = new Form2(username);
            this.Hide();
            HP.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

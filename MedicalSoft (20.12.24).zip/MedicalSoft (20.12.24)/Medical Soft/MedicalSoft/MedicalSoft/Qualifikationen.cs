﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Qualifikationen : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;

        public Qualifikationen()
        {
            InitializeComponent();
            textBox1.ReadOnly = true;
            panel2.Visible = false;
        }



        private void Qualifikationen_Load(object sender, EventArgs e)
        {




            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }



            try
            {
                cmd.CommandText = "select * from Qualifikation order by Q_ID asc";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0));
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Fehler");
                this.Close();
            }

            dr.Close();

            try
            {
                cmd.CommandText = "select * from Mitarbeiter order by M_ID asc";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    comboBox1.Items.Add(dr.GetInt32(0));
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Fehler");
                this.Close();
            }

            dr.Close();


            try
            {
                cmd.CommandText = "select * from Qualifikation order by Q_ID asc";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    comboBox2.Items.Add(dr.GetInt32(0));
                }


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }
            dr.Close();

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                try
                {
                    dr.Close();
                    cmd.CommandText = "select Q_ID, Q_Bezeichnung from Qualifikation where Q_ID = " + listBox1.SelectedItem;

                    cmd.Connection = con;
                    dr = cmd.ExecuteReader();

                    dr.Read();

                    textBox1.Text = dr.GetInt32(0).ToString();
                    textBox2.Text = dr.GetString(1);

                    dr.Close();
                }
                catch (Exception a)
                {

                    MessageBox.Show("f" + a);
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                dr.Close();
                cmd.CommandText = "update Qualifikation  set Q_Bezeichnung = '" + textBox2.Text + "' where Q_ID = " + listBox1.SelectedItem;

                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Die Qualifikation wurde erfolgreich geupdatet");

                dr.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Es wurde keine Qualifkation ausgewählt !", "Achtung");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Es wurde kein Mitarbeiter zum Löschen ausgewählt", "Achtung");
                }
                else
                {
                    dr.Close();

                    cmd.CommandText = "delete from Mitarbeiter_Qualifikationen where MQ_Q_ID = " + listBox1.SelectedItem.ToString();

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Die Qualifikation wurde gelöscht");

                    dr.Close();

                }


            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }

            try
            {

                if (textBox2.Text == "")
                {
                    
                }
                else
                {

                    dr.Close();
                    cmd.CommandText = "delete from Qualifikation where Q_ID = " + listBox1.SelectedItem.ToString();

                    cmd.ExecuteNonQuery();



                    dr.Close();

                }

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }

            refill();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            Q_ID();
        }

        void Q_ID()
        {
            try
            {
                cmd.CommandText = "Select max(Q_ID)+1 from Qualifikation ";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                dr.Read();

                textBox6.Text = (dr.GetInt32(0).ToString());
                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler" + a);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Bitte füllen Sie die Felder aus um eine Qualifikation anlegen zu können");
            }
            else
            {
                try
                {
                    dr.Close();
                    cmd.CommandText = "insert into Qualifikation (Q_ID, Q_Bezeichnung) values (" + textBox6.Text + " , '" + textBox5.Text + "')";
                    cmd.Connection = con;

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Es wurde eine neue Qualifikation angelegt");

                    Q_ID();

                    refill();
                }
                catch (Exception a)
                {
                    MessageBox.Show("f" + a);

                }

            }


            panel2.Visible = false;
            textBox5.Clear();
        }


        void refill()
        {
            try
            {
                dr.Close();
                cmd.CommandText = "select * from Qualifikation order by Q_ID asc";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                listBox1.Items.Clear();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0));
                }

                dr.Close();


            }
            catch (Exception)
            {
                MessageBox.Show("Fehler");
                this.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
          
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Wollen Sie dem Mitarbeiter " + textBox3.Text + " die Qualifiaktion " + label10.Text + "hinzufügen? ", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cmd.CommandText = "insert into Mitarbeiter_Qualifikationen (MQ_Q_ID, MQ_M_ID) values (" + comboBox2.SelectedItem + " , " + comboBox1.SelectedItem + ")";
                    cmd.ExecuteNonQuery();
                }






            }
            catch (Exception a)
            {

                MessageBox.Show("Dieser Mitarbeiter hat bereits diese Qualifikation oder es wurde kein Mitarbeiter ausgewähl!");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                dr.Close();
                cmd.CommandText = "select M_ID, M_Name from Mitarbeiter where M_ID =" + comboBox1.SelectedItem;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();



                textBox3.Text = dr.GetString(1);



                dr.Close();


            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dr.Close();
                cmd.CommandText = "select Q_Bezeichnung from Qualifikation where Q_ID = " + comboBox2.SelectedItem;
                dr = cmd.ExecuteReader();

                dr.Read();

                label10.Text = dr.GetString(0);

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form Q = new Mitarbeiter();
            this.Hide();
            Q.ShowDialog();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Operation : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;
        DataSet dataset = new DataSet();
        OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter();
        DataTable dt = new DataTable();
        public Operation()
        {
            InitializeComponent();
        }


        private void Operation_Load(object sender, EventArgs e)
        {
            label20.Visible = false;
            label21.Visible = false;
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox6.ReadOnly = true;
            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;
            textBox9.ReadOnly = true;
            textBox10.ReadOnly = true;
            textBox11.ReadOnly = true;
            richTextBox1.ReadOnly = true;
            dateTimePicker1.Enabled = false;
            dateTimePicker3.Enabled = false;
            dateTimePicker4.Enabled = false;

            // Datenbank-Verbindung herstellen
            try
            {

                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";
                con.Open();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }

            MaxOP_ID();
            Fill_Patient_ID();
            Fill_Aufenthalt_ID();
            Fill_Saal_ID();
            Fill_OP_Art_ID();

        }

        void MaxOP_ID()
        {
            try
            {
                cmd.CommandText = "Select max(OP_ID) +1 from Operation";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox1.Text = dr.GetInt32(0).ToString();
                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void Fill_Patient_ID()
        {
            try
            {
                cmd.CommandText = "Select * from Patient order by P_ID";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox1.Items.Clear();

                while (dr.Read())
                {
                    comboBox1.Items.Add(dr.GetInt32(0));
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void Fill_Aufenthalt_ID()
        {
            try
            {
                cmd.CommandText = "Select * from Aufenthalt order by A_ID";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox4.Items.Clear();

                while (dr.Read())
                {
                    comboBox4.Items.Add(dr.GetInt32(0));
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void Fill_Saal_ID()
        {
            try
            {
                cmd.CommandText = "Select OPS_ID from OP_Saal where OPS_Nutzungsstatus='Nein' order by OPS_ID";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox2.Items.Clear();

                while (dr.Read())
                {
                    comboBox2.Items.Add(dr.GetInt32(0));
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void Fill_OP_Art_ID()
        {
            try
            {
                cmd.CommandText = "Select * from OP_Art order by OPA_ID";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox3.Items.Clear();

                while (dr.Read())
                {
                    comboBox3.Items.Add(dr.GetInt32(0));
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void FillDataGrid()
        {
            try
            {
                //cmd.CommandText = "Select Q_ID, Q_Bezeichnung, OPAQ_Anzahl, MQ_M_ID, M_Name " +
                //  "from Qualifikation, OP_Art_Qualifikation, Mitarbeiter_Qualifikationen, Mitarbeiter " +
                //  "where M_ID = MQ_M_ID and MQ_Q_ID = Q_ID and Q_ID = OPAQ_Q_ID and OPAQ_OPA_ID = " + comboBox3.SelectedItem.ToString();

                cmd.CommandText = "Select Q_ID, Q_Bezeichnung, OPAQ_Anzahl " +
                    "from Qualifikation, OP_Art_Qualifikation " +
                    "where Q_ID = OPAQ_Q_ID and OPAQ_OPA_ID = " + comboBox3.SelectedItem.ToString();
                cmd.Connection = con;

                oleDbDataAdapter.SelectCommand = cmd;
                dt.Clear();
                oleDbDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderCell.Value = "Qualifikation-ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Bezeichnung";
                dataGridView1.Columns[2].HeaderCell.Value = "Anzahl";
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Sind Sie sicher, dass Sie zurück gehen möchten? Alle eingegebenen Daten würden verloren gehen.", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                Form H = new Form2(System.Convert.ToString(textBox1.Text));
                this.Hide();
                H.ShowDialog();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "Select * from Patient where P_ID = " + comboBox1.SelectedItem.ToString();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox2.Text = dr.GetString(2);
                textBox3.Text = dr.GetString(1);
                textBox4.Text = dr.GetString(4);
                dateTimePicker1.Text = dr.GetDateTime(3).ToString();

                dr.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// OP anlegen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                // Wenn keine Dauer für die OP angegeben wurde
                if (textBox5.Text == "")
                {
                    MessageBox.Show("Bitte geben Sie die Dauer der zu erfassenden Operation ein.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Wenn kein Aufenthalt ausgewählt wurde
                if (comboBox4.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte wählen Sie einen Aufenthalt aus. Sie können auch gegebenfalls einen neuen Aufenthalt erfassen.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Wenn kein OP-Saal ausgewählt wurde
                if (comboBox2.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte wählen Sie einen Operationssaal aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Wenn keine OP-Art ausgewählt wurde
                if (comboBox3.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte wählen Sie eine Operationsart aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Wenn kein Patient der OP zugeordnet wurde 
                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte weisen Sie der Operation einen Patienten zu.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Überprüfen, ob auch das Datum der OP in der Zeit des Aufenthalts des Patienten liegt
                if (dateTimePicker2.Value < dateTimePicker3.Value || dateTimePicker2.Value > dateTimePicker4.Value)
                {
                    MessageBox.Show("Bitte stellen Sie sicher, dass das Operationsdatum in der Aufenthaltszeit des Patienten liegt.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Überprüfen, ob bereits schon mind. 1 Mitarbeiter der OP zugewiesen wurde
                if (richTextBox2.Text == "")
                {
                    MessageBox.Show("Bitte weisen Sie mind. 1 Mitarbeiter der jeweiligen Operation zu.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Sind Sie sicher, dass Sie eine neue Operation anlegen möchten?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialogResult == DialogResult.Yes)
                {

                    cmd.CommandText = "Insert into Operation (OP_ID, OP_Datum, OP_Dauer, OP_P_ID, OP_OPA_ID, OP_OPS_ID, OP_A_ID) values (" + textBox1.Text + ", '" + dateTimePicker2.Value + "', " + textBox5.Text + ", " + comboBox1.SelectedItem.ToString() + ", " + comboBox3.SelectedItem.ToString() + ", " + comboBox2.SelectedItem.ToString() + ", " + comboBox4.SelectedItem.ToString() + ")";
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sie haben erfolgreich eine neue Operation angelegt.");

                    // Nutzungsstatus des OP-Saals wird auf Ja gesetzt
                    cmd.CommandText = "Update OP_Saal set OPS_Nutzungsstatus='Ja' where OPS_ID = " + comboBox2.SelectedItem.ToString();
                    cmd.ExecuteNonQuery();

                }

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            label20.Visible = true;
            label21.Visible = true;

            try
            {
                cmd.CommandText = "Select * from Aufenthalt where A_ID = " + comboBox4.SelectedItem.ToString();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox9.Text = dr.GetInt32(3).ToString();
                dateTimePicker3.Text = dr.GetDateTime(1).ToString();
                dateTimePicker4.Text = dr.GetDateTime(2).ToString();

                dr.Close();

                cmd.CommandText = "Select * from Bett where B_ID = " + textBox9.Text;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox10.Text = dr.GetInt32(4).ToString();
                label21.Text = dr.GetString(1);

                dr.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Form A = new Aufenthalt();
            this.Hide();
            A.ShowDialog();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                cmd.CommandText = "Select * from OP_Saal where OPS_ID = " + comboBox2.SelectedItem.ToString();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox6.Text = dr.GetString(1);
                richTextBox1.Text = dr.GetString(2);
                textBox7.Text = dr.GetInt32(3).ToString();
                textBox8.Text = dr.GetString(4);

                dr.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void label24_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "Select OPA_Bezeichnung from OP_Art where OPA_ID = " + comboBox3.SelectedItem.ToString();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox11.Text = dr.GetString(0);

                dr.Close();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }

            FillDataGrid();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte wählen Sie die ganze Zeile aus, um Mitarbeiter nach ihren Qualifikationen zu suchen.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string QualifikationID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

            Form M = new Mitarbeiter_Zuweisung(Convert.ToInt32(textBox1.Text), QualifikationID);
            M.ShowDialog();
        }

        /// <summary>
        /// Button zur Abwicklung der OP
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {

            // Abfrage, ob die OP wirklich abgewickelt werden soll und eine Rechnung erstellt werden soll

            if (MessageBox.Show("Wollen Sie diese OP wirklich abwickeln Sie können keine Daten danach mehr ändern!", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
            {
                return;
            }


            // Erstmal eine Abrage, ob die OP bereits angelegt wurde
            // Danach wird kein Zurückgehen ermöglicht, d.h. es können beispielsweise keine weiteren Mitarbeiter zugewiesen werden können
            try
            {

                cmd.CommandText = "SELECT COUNT(*) FROM Operation WHERE OP_ID = " + textBox1.Text;
                cmd.Connection = con;

                int count = (int)cmd.ExecuteScalar();

                if (count > 0)
                {
                    int ID = System.Convert.ToInt32(textBox1.Text);
                    string pname = textBox2.Text;

                    Form Abrechnung = new Abrechnung(ID, pname);
                    this.Hide();
                    Abrechnung.ShowDialog();

                }
                else
                {

                    MessageBox.Show("Bitte legen Sie zuerst eine OP an um fortfahren zu können.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler: " + a, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }









        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {

        }
    }
}

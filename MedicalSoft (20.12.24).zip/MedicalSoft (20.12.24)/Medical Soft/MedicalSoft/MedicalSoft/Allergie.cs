﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Allergie : Form
    {

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;

        int Patient;
        string PatientName;

        public Allergie(int P, string PN)
        {
            InitializeComponent();

            Patient = P;
            PatientName = PN;

            label8.Text = P.ToString();
            textBox1.Text = PN;

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;

        }

        private void Allergie_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }


            bereitsvorhandeneAllergien();
            Allergielistbox();

        }



        void Allergielistbox()
        {
            try
            {


                cmd.CommandText = "SELECT AL_ID, AL_Bezeichnung FROM Allergie";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox2.Items.Clear();

                while (dr.Read())
                {
                    string item = dr.GetInt32(0).ToString() + " - " + dr.GetString(1);
                    listBox2.Items.Add(item);

                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Bitte klicken Sie auf die ID der Allergie", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        void bereitsvorhandeneAllergien()
        {
            try
            {

                cmd.CommandText = "SELECT P_Al_ID, Al_Bezeichnung FROM Patient_Allergie, Allergie Where AL_ID = P_al_ID and PA_P_ID = " + label8.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox3.Items.Clear();

                while (dr.Read())
                {
                    string item = dr.GetInt32(0).ToString() + " - " + dr.GetString(1);
                    listBox3.Items.Add(item);

                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Bitte klicken Sie auf die ID des Patienten um die Befunde aufgelistet zu bekommen" + a, "Achtund", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        // Füllen der Listboxen

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {


                if (listBox2.SelectedItem != null)
                {
                    string selectedItem = listBox2.SelectedItem.ToString();

                    string[] parts = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None);

                    string idString = parts[0];


                    int selectedID = int.Parse(idString);

                    cmd.CommandText = "Select Al_ID, AL_Bezeichnung from Allergie WHERE AL_ID = " + selectedID;
                    dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        label5.Text = dr.GetInt32(0).ToString();
                        textBox2.Text = dr.GetString(1);

                    }


                    dr.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie eine Allergie aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Bitte klicken Sie auf die ID des Patienten um die Befunde aufgelistet zu bekommen" + a, "Achtund", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {


                cmd.CommandText = "Select P_ID, P_Name from Patient Where P_ID =" + label8.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                label4.Text = dr.GetInt32(0).ToString();

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("" + a, "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            bereitsvorhandeneAllergien();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            // hinzufügen einer Allergie für einen Patienten
            try
            {


                if (label8.Text == "" || label5.Text == "") return;

                cmd.CommandText = "Insert into Patient_Allergie (PA_P_ID, P_Al_ID) values (" + label8.Text + ", " + label5.Text + ")";
                cmd.ExecuteNonQuery();

                MessageBox.Show("Sie haben dem Patienten eine Allergie hinzugefügt", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception a)
            {

                MessageBox.Show("Der Patient hat breits diese Allergie!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            bereitsvorhandeneAllergien();

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {


                if (listBox3.SelectedItem != null)
                {
                    string selectedItem = listBox3.SelectedItem.ToString();

                    string[] parts = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None);

                    string idString = parts[0];


                    int selectedID = int.Parse(idString);

                    cmd.CommandText = "Select Al_ID, AL_Bezeichnung from Allergie WHERE AL_ID = " + selectedID;
                    dr = cmd.ExecuteReader();


                    dr.Read();

                    label6.Text = dr.GetInt32(0).ToString();
                    textBox3.Text = dr.GetString(1);




                    dr.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie ", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("" + a, "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Löschen einer Allergie von einem Patienten

            try
            {

                if (string.IsNullOrEmpty(textBox3.Text))
                {
                    MessageBox.Show("Bitte wählen Sie eine bereits vorhandene Allergie aus um Sie Löschen zu können!", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                cmd.CommandText = "Delete From Patient_Allergie WHERE PA_P_ID = " + label8.Text + " and P_Al_ID = " + label6.Text;
                cmd.ExecuteNonQuery();

                MessageBox.Show("Sie haben die Allergie vom Patienten gelöscht!", "info", MessageBoxButtons.OK, MessageBoxIcon.Information);



                textBox3.Clear();
                label6.Text = "";


                bereitsvorhandeneAllergien();
            }
            catch (Exception a)
            {

                MessageBox.Show("" + a);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Abrechnung_Übersicht : Form
    {
        public Abrechnung_Übersicht()
        {
            InitializeComponent();


            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox6.ReadOnly = true;
        }

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        OleDbDataReader dr = null;
        DataTable dt = new DataTable();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string username = null;

            Form HP = new Form2(username);
            this.Hide();
            HP.ShowDialog();
        }

        private void Abrechnung_Übersicht_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }

            //Abrechnungsübersicht Alle Abrechnungen in einem Datagrid 
            fillDatagrid();

        }

        void fillDatagrid()
        {
            try
            {

                cmd.Connection = con;
                cmd.CommandText = "SELECT RE_ID, RE_Datum, RE_OP_ID, P_ID, P_Name, KV_Kassennummer, KV_Name, OPA_ID, OPA_Bezeichnung, K_IBAN from Krankenhaus, Rechnung, Operation, Patient, OP_art, Krankenversicherung WHERE " +
                    " RE_OP_ID = OP_ID and OP_P_ID = P_ID and KV_ID = P_KV_ID and OPA_ID = OP_OPA_ID order by RE_ID";

                da.SelectCommand = cmd;
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderCell.Value = "Rechnungs ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Rechnungsdatum";
                dataGridView1.Columns[2].HeaderCell.Value = "OP NR";
                dataGridView1.Columns[3].HeaderCell.Value = "Patienten ID";
                dataGridView1.Columns[4].HeaderCell.Value = "Patienten Name";
                dataGridView1.Columns[5].HeaderCell.Value = "Kassennummer";
                dataGridView1.Columns[6].HeaderCell.Value = "Krankenkasse";
                dataGridView1.Columns[7].HeaderCell.Value = "OP Art ID";
                dataGridView1.Columns[8].HeaderCell.Value = "OP Art";
                dataGridView1.Columns[9].HeaderCell.Value = "Krankenhaus IBAN";


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //Berechnung der Kosten
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie links auf die ganze Zeile ");

            }
            else
            {
                try
                {
                    string OP_Art_ID = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
                    DateTime Rechnungsdatum = (DateTime)dataGridView1.SelectedRows[0].Cells[1].Value;


                    // Die MWST bestimmen

                    GETMWST(Rechnungsdatum);


                    // Berechnung der Gesamtkosten für Sachmittel

                    try
                    {

                        cmd.CommandText = "SELECT sum(OPAS_Menge * S_Pauschale) from Sachmittel, OP_art_Sachmittel, OP_art WHERE " +
                            "OPA_ID = OPAS_OPA_ID and OPAS_S_ID = S_ID and OPA_ID = " + OP_Art_ID;
                        cmd.Connection = con;
                        dr = cmd.ExecuteReader();

                        dr.Read();

                        textBox2.Text = dr.GetValue(0).ToString();

                        dr.Close();



                    }
                    catch (Exception a)
                    {

                        MessageBox.Show("Test" + a);
                    }


                    // Berechnung der Gesamtkosten für Leistung


                    try
                    {

                        cmd.CommandText = "SELECT sum(OPAL_Anzahl * L_Pauschale) from Leistung, OP_art_Leistung, OP_art WHERE " +
                            "OPA_ID = OPAL_OPA_ID and OPAL_L_ID = L_ID and OPA_ID = " + OP_Art_ID;
                        cmd.Connection = con;
                        dr = cmd.ExecuteReader();

                        dr.Read();

                        textBox1.Text = dr.GetValue(0).ToString();
                        Console.WriteLine("bla " + textBox1.Text);

                        dr.Close();



                    }
                    catch (Exception a)
                    {

                        MessageBox.Show("Test" + a);
                    }

                    // Berechnung der Gesamtkosten
                    try
                    {
                        double Gesamtkosten;

                        Console.WriteLine("test " + textBox1.Text);
                        double Leistungskosten = System.Convert.ToDouble(textBox1.Text);
                        double Sachmittelkosten = System.Convert.ToDouble(textBox2.Text);

                        Gesamtkosten = Leistungskosten + Sachmittelkosten;

                        textBox4.Text = Gesamtkosten.ToString();


                    }
                    catch (Exception a)
                    {

                        MessageBox.Show("Sie müssen Zuerst der OP Sachmittel und Leistungen zuweisen um fortfahren zu können"+ a, "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }


                    // mit MWST




                    try
                    {
                        double Gesamtkosten_Mit_MWST, MWST_in_EURO;

                        double GS = System.Convert.ToDouble(textBox4.Text);
                        double MWST = System.Convert.ToDouble(textBox3.Text);

                        MWST_in_EURO = GS * MWST / 100;

                        textBox5.Text = MWST_in_EURO.ToString();

                        Gesamtkosten_Mit_MWST = MWST_in_EURO + GS;

                        textBox6.Text = Gesamtkosten_Mit_MWST.ToString();



                    }
                    catch (Exception a)
                    {

                        MessageBox.Show("Test" + a);
                    }


                }
                catch (Exception a)
                {

                    MessageBox.Show("Bitte klicken Sie einen bereits vorhandenen Datensatz aus.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        void GETMWST(DateTime DT)
        {
            // MWST 

            try
            {

                cmd.CommandText = "Select MWST_Satz, MWST_Datum From MWST";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();


                double mwst = 0;
                DateTime aeltestesdatum = DateTime.MinValue;

                while (dr.Read())
                {

                    DateTime Date = System.Convert.ToDateTime(dr.GetValue(1));

                    double MWST = System.Convert.ToDouble(dr.GetValue(0));

                    if (DT.CompareTo(Date) > 0)
                    {
                        if (aeltestesdatum.CompareTo(Date) < 0)
                        {
                            mwst = MWST;
                            aeltestesdatum = Date;
                        }

                    }

                }

                textBox3.Text = mwst.ToString();
                dr.Close();


            }
            catch (Exception a)
            {

                Console.WriteLine(a);
            }
        }


        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}

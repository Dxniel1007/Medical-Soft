﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Aufenthalt : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;
        public Aufenthalt()
        {
            InitializeComponent();
        }

        private void Aufenthalt_Load(object sender, EventArgs e)
        {
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;

            // Datenbank-Verbindung herstellen
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";
                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }

            MaxAufenthalt_ID();
            Fill_Bett_ID();

        }

        void MaxAufenthalt_ID()
        {
            try
            {
                cmd.CommandText = "Select max(A_ID) +1 from Aufenthalt";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox1.Text = dr.GetInt32(0).ToString();
                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        void Fill_Bett_ID()
        {
            try
            {
                cmd.CommandText = "Select B_ID from Bett where B_Belegt=false order by B_ID";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox1.Items.Clear();

                while (dr.Read())
                {
                    comboBox1.Items.Add(dr.GetInt32(0));
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        /// <summary>
        /// Hinzufügen eines neuen Aufenthaltes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                if (comboBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Bitte wählen Sie eine Bett-ID aus!", "Hinweis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (dateTimePicker1.Value > dateTimePicker2.Value)
                {
                    MessageBox.Show("Bitte legen Sie das Aufenthaltsende-Datum nach dem Aufenthaltsanfang-Datum", "Hinweis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                DialogResult dialogResult = MessageBox.Show("Möchten Sie wirklich einen neuen Aufenthalt hinzufügen?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialogResult == DialogResult.Yes)
                {
                    cmd.CommandText = "Insert into Aufenthalt (A_ID, A_Beginn, A_Ende, A_B_ID) values (" + textBox1.Text + ", '" + dateTimePicker1.Value + "', '" + dateTimePicker2.Value + "', " + comboBox1.SelectedItem.ToString() + ")";
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Neuer Aufenthalt wurde erfolgreich hinzugefügt");

                    //Zugewiesenes Bett nun als Belegt festlegen, da neuer Aufenthalt mit dieser Bett-ID erfasst wurde
                    cmd.CommandText = "Update Bett set B_Belegt=true where B_ID = " + comboBox1.SelectedItem.ToString();
                    cmd.ExecuteNonQuery();

                    Form O = new Operation();
                    this.Hide();
                    O.ShowDialog();
                }

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form O = new Operation();
            this.Hide();
            O.ShowDialog();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "Select B_Typ, B_Z_ID from Bett where B_ID = " + comboBox1.SelectedItem.ToString();
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox3.Text = dr.GetString(0);
                textBox4.Text = dr.GetInt32(1).ToString();
                dr.Close();

                cmd.CommandText = "Select Z_Typ from Zimmer where Z_ID = " + textBox4.Text;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox2.Text = dr.GetString(0);
                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }



        }
    }
}

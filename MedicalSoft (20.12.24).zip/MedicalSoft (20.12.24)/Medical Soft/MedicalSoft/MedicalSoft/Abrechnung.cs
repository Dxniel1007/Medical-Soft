﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Abrechnung : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        DataTable dtLeistung = new DataTable();
        DataTable dtSachmittel = new DataTable();




        int Operation_Nr;
        string Patient_Name;

        public Abrechnung(int ID, string Pname)
        {
            InitializeComponent();

            Operation_Nr = ID;
            Patient_Name = Pname;

            label3.Text = Operation_Nr.ToString();
            label4.Text = Patient_Name;


            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox3.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox6.ReadOnly = true;
            textBox7.ReadOnly = true;
            textBox8.ReadOnly = true;



        }

        private void Abrechnung_Load(object sender, EventArgs e)
        {
            // Datenbankverbindung herstellen
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";
                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }


            // Autowert ABR

            ABRAutowert();


            textBox2.Text = "Klinik Hannover";


            try
            {
                cmd.CommandText = "Select OP_OPA_ID from Operation WHERE OP_ID = " + label3.Text;
                dr = cmd.ExecuteReader();

                dr.Read();

                label10.Text = dr.GetInt32(0).ToString();
                dr.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }

            // MWST

            GETMWST(DateTime.Today);

            // Filldatagrid

            Filldatagrids();




        }



        void ABRAutowert()
        {
            try
            {

                cmd.CommandText = "select max(RE_ID)+1 from Rechnung";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox1.Text = dr.GetInt32(0).ToString();

                dr.Close();



            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }
        }

        void GETMWST(DateTime DT)
        {
            // MWST 

            try
            {

                cmd.CommandText = "Select MWST_Satz, MWST_Datum From MWST";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();


                double mwst = 0;
                DateTime aeltestesdatum = DateTime.MinValue;

                while (dr.Read())
                {

                    DateTime Date = System.Convert.ToDateTime(dr.GetValue(1));

                    double MWST = System.Convert.ToDouble(dr.GetValue(0));

                    if (DT.CompareTo(Date) > 0)
                    {
                        if (aeltestesdatum.CompareTo(Date) < 0)
                        {
                            mwst = MWST;
                            aeltestesdatum = Date;
                        }

                    }

                }

                textBox3.Text = mwst.ToString();
                dr.Close();


            }
            catch (Exception a)
            {

                Console.WriteLine(a);
            }
        }

        void Filldatagrids()
        {
            try
            {

                DataTable dataTable = (DataTable)dataGridView1.DataSource;
                DataTable dataTable2 = (DataTable)dataGridView2.DataSource;
                if (dataTable != null || dataTable2 != null)
                {
                    dataTable.Rows.Clear();
                    dataTable2.Rows.Clear();
                }

                cmd.Connection = con;

                cmd.CommandText = "SELECT  OPAL_L_ID, OPAL_Anzahl, L_Bezeichnung, L_Pauschale, OPAL_Anzahl * L_Pauschale as Gesamtkosten FROM Leistung, OP_art_Leistung WHERE OPAL_L_ID = L_ID and OPAL_OPA_ID = " + label10.Text + " order by OPAL_L_ID  ";
                da.SelectCommand = cmd;
                da.Fill(dtLeistung);
                dataGridView1.DataSource = dtLeistung;


                cmd.CommandText = "SELECT OPAS_S_ID, OPAS_Menge, S_Bezeichnung, S_Pauschale, OPAS_Menge * S_Pauschale as Gesamtkosten FROM Sachmittel, OP_art_Sachmittel WHERE OPAS_S_ID = S_ID and OPAS_OPA_ID = " + label10.Text + " order by OPAS_S_ID ";
                da.SelectCommand = cmd;
                da.Fill(dtSachmittel);
                dataGridView2.DataSource = dtSachmittel;

                dataGridView1.Columns[0].HeaderCell.Value = "Leistungs ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Anzahl";
                dataGridView1.Columns[2].HeaderCell.Value = "Bezeichnung";
                dataGridView1.Columns[3].HeaderCell.Value = "Pauschalpreis";



                dataGridView2.Columns[0].HeaderCell.Value = "Sachmittel ID";
                dataGridView2.Columns[1].HeaderCell.Value = "Menge";
                dataGridView2.Columns[2].HeaderCell.Value = "Bezeichnung";
                dataGridView2.Columns[3].HeaderCell.Value = "Pauschalpreis";





            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler: " + a);
            }


            // Berechnung der Gesamtkosten für Sachmittel

            try
            {

                cmd.CommandText = "SELECT sum(OPAS_Menge * S_Pauschale) from Sachmittel, OP_art_Sachmittel, OP_art WHERE " +
                    "OPA_ID = OPAS_OPA_ID and OPAS_S_ID = S_ID and OPA_ID = " + label10.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox7.Text = dr.GetValue(0).ToString();

                dr.Close();



            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }


            // Berechnung der Gesamtkosten für Leistung


            try
            {

                cmd.CommandText = "SELECT sum(OPAL_Anzahl * L_Pauschale) from Leistung, OP_art_Leistung, OP_art WHERE " +
                    "OPA_ID = OPAL_OPA_ID and OPAL_L_ID = L_ID and OPA_ID = " + label10.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox8.Text = dr.GetValue(0).ToString();
                Console.WriteLine("bla " + textBox8.Text);

                dr.Close();



            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }

            // Berechnung der Gesamtkosten
            try
            {
                double Gesamtkosten;

                Console.WriteLine("test " + textBox8.Text);
                double Leistungskosten = System.Convert.ToDouble(textBox8.Text);
                double Sachmittelkosten = System.Convert.ToDouble(textBox7.Text);

                Gesamtkosten = Leistungskosten + Sachmittelkosten;

                textBox4.Text = Gesamtkosten.ToString();


            }
            catch (Exception a)
            {

                MessageBox.Show("Sie müssen Zuerst der OP Sachmittel und Leistungen zuweisen um fortfahren zu können", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                string username = null;

                Form HP = new Form2(username);
                this.Hide();
                HP.ShowDialog();
            }


            // mit MWST




            try
            {
                double Gesamtkosten_Mit_MWST, MWST_in_EURO;

                double GS = System.Convert.ToDouble(textBox4.Text);
                double MWST = System.Convert.ToDouble(textBox3.Text);

                MWST_in_EURO = GS * MWST / 100;

                textBox6.Text = MWST_in_EURO.ToString();

                Gesamtkosten_Mit_MWST = MWST_in_EURO + GS;

                textBox5.Text = Gesamtkosten_Mit_MWST.ToString();



            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }




        }





        private void button1_Click(object sender, EventArgs e)
        {


            try
            {
                if (MessageBox.Show("Wollen Sie wirklich diese Rechnung wirklich abwickeln Im Anschluss können Sie Ihre Daten nicht mehr verändern", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) return;

                cmd.CommandText = "INSERT INTO Rechnung (RE_ID, RE_Datum, RE_OP_ID, R_K_Name, R_MWST_Satz) " +
                "VALUES (" + textBox1.Text.ToString() + ", '" + dateTimePicker1.Value + "', " + label3.Text.ToString() + ", '" + textBox2.Text + "', " + textBox3.Text.ToString() + ")";
                cmd.ExecuteNonQuery();


            }
            catch (Exception a)
            {

                MessageBox.Show("Dieser OP wurde bereits eine Abbrechnung zugewiesen", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }



              



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Ü = new OP_Übersicht();
            this.Hide();
            Ü.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            GETMWST(dateTimePicker1.Value);

            Filldatagrids();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Übersicht = new Abrechnung_Übersicht();
            this.Hide();
            Übersicht.ShowDialog();
        }
    }
}

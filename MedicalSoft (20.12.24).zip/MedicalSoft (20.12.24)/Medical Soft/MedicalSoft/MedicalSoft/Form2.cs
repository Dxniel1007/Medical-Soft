﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MedicalSoft
{
    public partial class Form2 : Form
    {

        string username1;
        public Form2(string username)
        {
            InitializeComponent();
            customsizedesign();
            username1 = username;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form A = new Form1();
            this.Hide();
            A.ShowDialog();

            hidesubmenu();
        }

        private void customsizedesign()
        {
            PanelStammdaten.Visible = false;

            panelOP.Visible = false;

            panelFunktionen.Visible = false;
        }

        private void hidesubmenu()
        {
            if (PanelStammdaten.Visible == true)
            {
                PanelStammdaten.Visible = false;
            }

            if (panelOP.Visible == true)
            {
                panelOP.Visible = false;
            }

            if (panelFunktionen.Visible == true)
            {
                panelFunktionen.Visible = false;
            }
        }

        private void showsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {

                submenu.Visible = true;
            }
            else
            {
                submenu.Visible = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            showsubmenu(PanelStammdaten);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            showsubmenu(panelOP);

        }

        private void button8_Click(object sender, EventArgs e)
        {
            showsubmenu(panelFunktionen);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form B = new Krankenversicherung();
            this.Hide();
            B.ShowDialog();

            hidesubmenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Mitarbeiter = new Mitarbeiter();
            this.Hide();
            Mitarbeiter.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form Leistungen = new Leistungen();
            this.Hide();
            Leistungen.ShowDialog();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            label3.Text = username1;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form Mitarbeiter = new Mitarbeiter();
            this.Hide();
            Mitarbeiter.ShowDialog();

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form Leistungen = new Leistungen();
            this.Hide();
            Leistungen.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
        
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form Operation = new Operation();
            this.Hide();
            Operation.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form Patienten = new Patientenverwaltung();
            this.Hide();
            Patienten.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
          
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Form OP_Übersicht = new OP_Übersicht();
            this.Hide();
            OP_Übersicht.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form ABR = new Abrechnung_Übersicht();
            this.Hide();
            ABR.ShowDialog();

        }
    }
}

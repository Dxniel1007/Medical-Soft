﻿
namespace MedicalSoft
{
    partial class Patientenverwaltung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.Hinzufuege = new System.Windows.Forms.Panel();
            this.AbbrechenPatient = new System.Windows.Forms.Button();
            this.HinzufuegePatient = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.Befundepanel = new System.Windows.Forms.Panel();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.befundinsert = new System.Windows.Forms.Button();
            this.befunddelete = new System.Windows.Forms.Button();
            this.Updatebefund = new System.Windows.Forms.Button();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label47 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.Allergiepanel = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.listBox6 = new System.Windows.Forms.ListBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.label67 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Hinzufuege.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Befundepanel.SuspendLayout();
            this.Allergiepanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(502, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(179, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Patientenverwaltung";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(63, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Suche";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(113, 67);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(110, 26);
            this.textBox1.TabIndex = 2;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(259, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 3;
            this.label3.Text = "Suchkriterium";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "ID",
            "Name",
            "Vorname",
            "Stadt",
            "Land",
            "Straße"});
            this.comboBox1.Location = new System.Drawing.Point(354, 69);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(96, 26);
            this.comboBox1.TabIndex = 4;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(66, 121);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(878, 226);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDoubleClick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(950, 155);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 44);
            this.button1.TabIndex = 6;
            this.button1.Text = "Befunde";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(950, 218);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 44);
            this.button2.TabIndex = 7;
            this.button2.Text = "Röntgen";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(950, 278);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(110, 44);
            this.button3.TabIndex = 8;
            this.button3.Text = "Allergie";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(66, 385);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(72, 23);
            this.textBox2.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(72, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 15);
            this.label4.TabIndex = 10;
            this.label4.Text = "ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(182, 369);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 15);
            this.label5.TabIndex = 12;
            this.label5.Text = "Name";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(176, 385);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(112, 23);
            this.textBox3.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(325, 369);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 15);
            this.label6.TabIndex = 14;
            this.label6.Text = "Vorname";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(319, 385);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(112, 23);
            this.textBox4.TabIndex = 13;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(480, 382);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(186, 23);
            this.dateTimePicker1.TabIndex = 15;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(478, 365);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 15);
            this.label7.TabIndex = 16;
            this.label7.Text = "Geburtsdatum";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Männlich",
            "Weiblich",
            "Divers"});
            this.comboBox2.Location = new System.Drawing.Point(678, 387);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(104, 23);
            this.comboBox2.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(687, 369);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(74, 15);
            this.label8.TabIndex = 18;
            this.label8.Text = "Geschlecht";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(72, 417);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 15);
            this.label9.TabIndex = 20;
            this.label9.Text = "Größe";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(66, 433);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(72, 23);
            this.textBox5.TabIndex = 19;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(180, 417);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 15);
            this.label10.TabIndex = 22;
            this.label10.Text = "Gewicht";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(176, 433);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(72, 23);
            this.textBox6.TabIndex = 21;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(288, 417);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 15);
            this.label11.TabIndex = 24;
            this.label11.Text = "Blutgruppe";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(284, 433);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(72, 23);
            this.textBox7.TabIndex = 23;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(400, 417);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 15);
            this.label12.TabIndex = 26;
            this.label12.Text = "Telefon";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(394, 435);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(144, 23);
            this.textBox8.TabIndex = 25;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(583, 417);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 15);
            this.label13.TabIndex = 28;
            this.label13.Text = "Handy-Telefon";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(577, 435);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(144, 23);
            this.textBox9.TabIndex = 27;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(63, 464);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 15);
            this.label14.TabIndex = 30;
            this.label14.Text = "E-mail";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(66, 484);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(144, 23);
            this.textBox10.TabIndex = 29;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(250, 466);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 15);
            this.label15.TabIndex = 32;
            this.label15.Text = "Straße";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(244, 484);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(144, 23);
            this.textBox11.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(411, 464);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 15);
            this.label16.TabIndex = 34;
            this.label16.Text = "Haus Nummer";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(414, 482);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(72, 23);
            this.textBox12.TabIndex = 33;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(519, 464);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 15);
            this.label17.TabIndex = 36;
            this.label17.Text = "PLZ";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(522, 482);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(144, 23);
            this.textBox13.TabIndex = 35;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(687, 464);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(39, 15);
            this.label18.TabIndex = 38;
            this.label18.Text = "Stadt";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(690, 482);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(144, 23);
            this.textBox14.TabIndex = 37;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(72, 516);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 15);
            this.label19.TabIndex = 40;
            this.label19.Text = "Land";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(66, 534);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(144, 23);
            this.textBox15.TabIndex = 39;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(250, 516);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(36, 15);
            this.label20.TabIndex = 42;
            this.label20.Text = "IBAN";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(244, 534);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(144, 23);
            this.textBox16.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(411, 516);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(153, 15);
            this.label21.TabIndex = 44;
            this.label21.Text = "Krankenversicherung NR";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(563, 516);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(104, 15);
            this.label22.TabIndex = 46;
            this.label22.Text = "Versicherten NR";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(571, 534);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(72, 23);
            this.textBox18.TabIndex = 45;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button4.Location = new System.Drawing.Point(66, 564);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(157, 36);
            this.button4.TabIndex = 47;
            this.button4.Text = "Update";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button5.Location = new System.Drawing.Point(244, 560);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(157, 36);
            this.button5.TabIndex = 48;
            this.button5.Text = "Löschen";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button6.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button6.Location = new System.Drawing.Point(419, 560);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(157, 36);
            this.button6.TabIndex = 49;
            this.button6.Text = "Hinzufügen";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button7.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button7.Location = new System.Drawing.Point(66, 602);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(157, 36);
            this.button7.TabIndex = 50;
            this.button7.Text = "Rückgängig";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // listBox1
            // 
            this.listBox1.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 18;
            this.listBox1.Location = new System.Drawing.Point(253, 624);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(103, 58);
            this.listBox1.TabIndex = 51;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // Hinzufuege
            // 
            this.Hinzufuege.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Hinzufuege.Controls.Add(this.AbbrechenPatient);
            this.Hinzufuege.Controls.Add(this.HinzufuegePatient);
            this.Hinzufuege.Controls.Add(this.groupBox3);
            this.Hinzufuege.Controls.Add(this.groupBox2);
            this.Hinzufuege.Controls.Add(this.groupBox1);
            this.Hinzufuege.Controls.Add(this.label23);
            this.Hinzufuege.Dock = System.Windows.Forms.DockStyle.Right;
            this.Hinzufuege.Location = new System.Drawing.Point(1076, 0);
            this.Hinzufuege.Name = "Hinzufuege";
            this.Hinzufuege.Size = new System.Drawing.Size(508, 732);
            this.Hinzufuege.TabIndex = 52;
            this.Hinzufuege.Paint += new System.Windows.Forms.PaintEventHandler(this.Hinzufuege_Paint);
            // 
            // AbbrechenPatient
            // 
            this.AbbrechenPatient.BackColor = System.Drawing.Color.Gray;
            this.AbbrechenPatient.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AbbrechenPatient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.AbbrechenPatient.Location = new System.Drawing.Point(245, 448);
            this.AbbrechenPatient.Name = "AbbrechenPatient";
            this.AbbrechenPatient.Size = new System.Drawing.Size(128, 45);
            this.AbbrechenPatient.TabIndex = 73;
            this.AbbrechenPatient.Text = "Abbrechen";
            this.AbbrechenPatient.UseVisualStyleBackColor = false;
            this.AbbrechenPatient.Click += new System.EventHandler(this.AbbrechenPatient_Click);
            // 
            // HinzufuegePatient
            // 
            this.HinzufuegePatient.BackColor = System.Drawing.Color.Gray;
            this.HinzufuegePatient.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HinzufuegePatient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.HinzufuegePatient.Location = new System.Drawing.Point(81, 448);
            this.HinzufuegePatient.Name = "HinzufuegePatient";
            this.HinzufuegePatient.Size = new System.Drawing.Size(128, 45);
            this.HinzufuegePatient.TabIndex = 72;
            this.HinzufuegePatient.Text = "Hinzufügen";
            this.HinzufuegePatient.UseVisualStyleBackColor = false;
            this.HinzufuegePatient.Click += new System.EventHandler(this.HinzufuegePatient_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox4);
            this.groupBox3.Controls.Add(this.textBox35);
            this.groupBox3.Controls.Add(this.label42);
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Font = new System.Drawing.Font("Roboto Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(278, 258);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(228, 155);
            this.groupBox3.TabIndex = 71;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Versicherung";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(96, 60);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 22);
            this.comboBox4.TabIndex = 83;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(96, 85);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(122, 22);
            this.textBox35.TabIndex = 81;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(-4, 87);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(100, 16);
            this.label42.TabIndex = 82;
            this.label42.Text = "Versicherten Nr";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(44, 65);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(42, 16);
            this.label41.TabIndex = 80;
            this.label41.Text = "KV Nr";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox32);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.textBox31);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.textBox33);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.textBox30);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.textBox29);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.textBox28);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Font = new System.Drawing.Font("Roboto Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(283, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(208, 196);
            this.groupBox2.TabIndex = 70;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Adresse";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(50, 135);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(122, 22);
            this.textBox32.TabIndex = 75;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(-1, 140);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(38, 16);
            this.label39.TabIndex = 76;
            this.label39.Text = "Land";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(50, 109);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(122, 22);
            this.textBox31.TabIndex = 73;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(6, 117);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(39, 16);
            this.label38.TabIndex = 74;
            this.label38.Text = "Stadt";
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(50, 161);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(122, 22);
            this.textBox33.TabIndex = 77;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(7, 166);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(39, 16);
            this.label40.TabIndex = 78;
            this.label40.Text = "IBAN";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(50, 83);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(122, 22);
            this.textBox30.TabIndex = 71;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(3, 89);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(32, 16);
            this.label37.TabIndex = 72;
            this.label37.Text = "PLZ";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(50, 57);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(122, 22);
            this.textBox29.TabIndex = 69;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(-6, 62);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(58, 16);
            this.label36.TabIndex = 70;
            this.label36.Text = "Haus-Nr";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(50, 31);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(122, 22);
            this.textBox28.TabIndex = 67;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(-6, 36);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(48, 16);
            this.label35.TabIndex = 68;
            this.label35.Text = "Straße";
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label66);
            this.groupBox1.Controls.Add(this.label65);
            this.groupBox1.Controls.Add(this.label64);
            this.groupBox1.Controls.Add(this.label60);
            this.groupBox1.Controls.Add(this.label59);
            this.groupBox1.Controls.Add(this.textBox20);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.textBox19);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.textBox27);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.textBox21);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.textBox26);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.textBox22);
            this.groupBox1.Controls.Add(this.textBox25);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.textBox23);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.textBox24);
            this.groupBox1.Font = new System.Drawing.Font("Roboto Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(3, 58);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(274, 347);
            this.groupBox1.TabIndex = 69;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stammdaten";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.Color.Red;
            this.label66.Location = new System.Drawing.Point(220, 304);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(21, 25);
            this.label66.TabIndex = 70;
            this.label66.Text = "*";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.Color.Red;
            this.label65.Location = new System.Drawing.Point(220, 281);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(21, 25);
            this.label65.TabIndex = 69;
            this.label65.Text = "*";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.Color.Red;
            this.label64.Location = new System.Drawing.Point(218, 255);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(21, 25);
            this.label64.TabIndex = 59;
            this.label64.Text = "*";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(220, 210);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(23, 16);
            this.label60.TabIndex = 68;
            this.label60.Text = "kg";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(220, 186);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(26, 16);
            this.label59.TabIndex = 67;
            this.label59.Text = "cm";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(80, 55);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(134, 22);
            this.textBox20.TabIndex = 14;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(28, 311);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(46, 16);
            this.label34.TabIndex = 66;
            this.label34.Text = "E-Mail";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(80, 29);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(134, 22);
            this.textBox19.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(56, 31);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 16);
            this.label24.TabIndex = 13;
            this.label24.Text = "ID";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(80, 309);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(134, 22);
            this.textBox27.TabIndex = 65;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(37, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(45, 16);
            this.label25.TabIndex = 15;
            this.label25.Text = "Name";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(80, 81);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(134, 22);
            this.textBox21.TabIndex = 16;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(5, 287);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(72, 16);
            this.label33.TabIndex = 64;
            this.label33.Text = "Handy-Tel";
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(21, 83);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(63, 16);
            this.label26.TabIndex = 17;
            this.label26.Text = "Vorname";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(84, 113);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(207, 21);
            this.dateTimePicker2.TabIndex = 18;
            this.dateTimePicker2.Value = new System.DateTime(2024, 12, 13, 0, 0, 0, 0);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(80, 283);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(134, 22);
            this.textBox26.TabIndex = 63;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(6, 118);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(92, 16);
            this.label27.TabIndex = 19;
            this.label27.Text = "Geburtsdatum";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Männlich",
            "Weiblich",
            "Divers"});
            this.comboBox3.Location = new System.Drawing.Point(80, 152);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(134, 22);
            this.comboBox3.TabIndex = 53;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(28, 259);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(54, 16);
            this.label32.TabIndex = 62;
            this.label32.Text = "Telefon";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(10, 154);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(75, 16);
            this.label28.TabIndex = 54;
            this.label28.Text = "Geschlecht";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(80, 179);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(134, 22);
            this.textBox22.TabIndex = 55;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(80, 257);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(134, 22);
            this.textBox25.TabIndex = 61;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(21, 181);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(46, 16);
            this.label29.TabIndex = 56;
            this.label29.Text = "Größe";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(80, 205);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(134, 22);
            this.textBox23.TabIndex = 57;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(13, 233);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(73, 16);
            this.label31.TabIndex = 60;
            this.label31.Text = "Blutgruppe";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(21, 207);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 16);
            this.label30.TabIndex = 58;
            this.label30.Text = "Gewicht";
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(80, 231);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(134, 22);
            this.textBox24.TabIndex = 59;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(177, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(117, 24);
            this.label23.TabIndex = 1;
            this.label23.Text = "Hinzufügen";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(403, 534);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(72, 23);
            this.textBox17.TabIndex = 43;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(486, 536);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(0, 15);
            this.label43.TabIndex = 53;
            // 
            // Befundepanel
            // 
            this.Befundepanel.BackColor = System.Drawing.Color.Silver;
            this.Befundepanel.Controls.Add(this.textBox34);
            this.Befundepanel.Controls.Add(this.label57);
            this.Befundepanel.Controls.Add(this.label45);
            this.Befundepanel.Controls.Add(this.label51);
            this.Befundepanel.Controls.Add(this.listBox3);
            this.Befundepanel.Controls.Add(this.button9);
            this.Befundepanel.Controls.Add(this.button8);
            this.Befundepanel.Controls.Add(this.befundinsert);
            this.Befundepanel.Controls.Add(this.befunddelete);
            this.Befundepanel.Controls.Add(this.Updatebefund);
            this.Befundepanel.Controls.Add(this.label50);
            this.Befundepanel.Controls.Add(this.textBox37);
            this.Befundepanel.Controls.Add(this.label49);
            this.Befundepanel.Controls.Add(this.richTextBox2);
            this.Befundepanel.Controls.Add(this.label48);
            this.Befundepanel.Controls.Add(this.dateTimePicker3);
            this.Befundepanel.Controls.Add(this.label47);
            this.Befundepanel.Controls.Add(this.richTextBox1);
            this.Befundepanel.Controls.Add(this.label46);
            this.Befundepanel.Controls.Add(this.textBox36);
            this.Befundepanel.Controls.Add(this.label44);
            this.Befundepanel.Location = new System.Drawing.Point(1076, 0);
            this.Befundepanel.Name = "Befundepanel";
            this.Befundepanel.Size = new System.Drawing.Size(508, 732);
            this.Befundepanel.TabIndex = 54;
            this.Befundepanel.Paint += new System.Windows.Forms.PaintEventHandler(this.Befundepanel_Paint);
            // 
            // textBox34
            // 
            this.textBox34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(128, 87);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(96, 24);
            this.textBox34.TabIndex = 22;
            this.textBox34.TextChanged += new System.EventHandler(this.textBox34_TextChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(105, 92);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(18, 13);
            this.label57.TabIndex = 21;
            this.label57.Text = "ID";
            this.label57.Click += new System.EventHandler(this.label57_Click_1);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(31, 91);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(62, 13);
            this.label45.TabIndex = 20;
            this.label45.Text = "Befund von";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(230, 50);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(190, 15);
            this.label51.TabIndex = 19;
            this.label51.Text = "Befund vom Patienten auswählen";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(230, 68);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(134, 69);
            this.listBox3.TabIndex = 18;
            this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Roboto Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(146, 499);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(131, 26);
            this.button9.TabIndex = 17;
            this.button9.Text = "hinzufügen";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button8.Location = new System.Drawing.Point(332, 624);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 34);
            this.button8.TabIndex = 16;
            this.button8.Text = "Schließen";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // befundinsert
            // 
            this.befundinsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.befundinsert.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.befundinsert.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.befundinsert.Location = new System.Drawing.Point(326, 345);
            this.befundinsert.Name = "befundinsert";
            this.befundinsert.Size = new System.Drawing.Size(120, 34);
            this.befundinsert.TabIndex = 15;
            this.befundinsert.Text = "Hinzufügen";
            this.befundinsert.UseVisualStyleBackColor = false;
            this.befundinsert.Click += new System.EventHandler(this.befundinsert_Click);
            // 
            // befunddelete
            // 
            this.befunddelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.befunddelete.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.befunddelete.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.befunddelete.Location = new System.Drawing.Point(326, 296);
            this.befunddelete.Name = "befunddelete";
            this.befunddelete.Size = new System.Drawing.Size(120, 34);
            this.befunddelete.TabIndex = 14;
            this.befunddelete.Text = "Löschen";
            this.befunddelete.UseVisualStyleBackColor = false;
            this.befunddelete.Click += new System.EventHandler(this.befunddelete_Click);
            // 
            // Updatebefund
            // 
            this.Updatebefund.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Updatebefund.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebefund.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Updatebefund.Location = new System.Drawing.Point(325, 244);
            this.Updatebefund.Name = "Updatebefund";
            this.Updatebefund.Size = new System.Drawing.Size(120, 34);
            this.Updatebefund.TabIndex = 13;
            this.Updatebefund.Text = "UPDATE";
            this.Updatebefund.UseVisualStyleBackColor = false;
            this.Updatebefund.Click += new System.EventHandler(this.Updatebefund_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(8, 475);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(97, 19);
            this.label50.TabIndex = 12;
            this.label50.Text = "Medikamente";
            // 
            // textBox37
            // 
            this.textBox37.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(127, 467);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(191, 27);
            this.textBox37.TabIndex = 11;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(2, 330);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(86, 19);
            this.label49.TabIndex = 10;
            this.label49.Text = "Behandlung";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox2.Location = new System.Drawing.Point(106, 327);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(212, 84);
            this.richTextBox2.TabIndex = 9;
            this.richTextBox2.Text = "";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(28, 441);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(51, 19);
            this.label48.TabIndex = 8;
            this.label48.Text = "Datum";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Location = new System.Drawing.Point(107, 435);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(257, 27);
            this.dateTimePicker3.TabIndex = 7;
            this.dateTimePicker3.Value = new System.DateTime(2024, 12, 3, 0, 0, 0, 0);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(28, 231);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(55, 19);
            this.label47.TabIndex = 6;
            this.label47.Text = "Befund";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(108, 229);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(212, 84);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(49, 199);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(22, 19);
            this.label46.TabIndex = 4;
            this.label46.Text = "ID";
            // 
            // textBox36
            // 
            this.textBox36.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(76, 193);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(96, 27);
            this.textBox36.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(196, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(99, 25);
            this.label44.TabIndex = 0;
            this.label44.Text = "Befunde";
            // 
            // Allergiepanel
            // 
            this.Allergiepanel.BackColor = System.Drawing.Color.Gray;
            this.Allergiepanel.Controls.Add(this.button10);
            this.Allergiepanel.Controls.Add(this.label55);
            this.Allergiepanel.Controls.Add(this.label54);
            this.Allergiepanel.Controls.Add(this.label53);
            this.Allergiepanel.Controls.Add(this.button13);
            this.Allergiepanel.Controls.Add(this.listBox6);
            this.Allergiepanel.Controls.Add(this.label56);
            this.Allergiepanel.Controls.Add(this.label52);
            this.Allergiepanel.Location = new System.Drawing.Point(1079, 0);
            this.Allergiepanel.Name = "Allergiepanel";
            this.Allergiepanel.Size = new System.Drawing.Size(505, 732);
            this.Allergiepanel.TabIndex = 20;
            this.Allergiepanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Roboto Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(362, 624);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(129, 32);
            this.button10.TabIndex = 16;
            this.button10.Text = "Schließen";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click_1);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(265, 69);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(51, 19);
            this.label55.TabIndex = 15;
            this.label55.Text = "Name";
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(197, 67);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(0, 19);
            this.label54.TabIndex = 14;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(25, 68);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(117, 19);
            this.label53.TabIndex = 13;
            this.label53.Text = "Allergien von: ";
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Roboto Condensed", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(52, 417);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(338, 41);
            this.button13.TabIndex = 12;
            this.button13.Text = "Allergien Verwalten";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // listBox6
            // 
            this.listBox6.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox6.FormattingEnabled = true;
            this.listBox6.ItemHeight = 18;
            this.listBox6.Location = new System.Drawing.Point(34, 176);
            this.listBox6.Name = "listBox6";
            this.listBox6.Size = new System.Drawing.Size(200, 94);
            this.listBox6.TabIndex = 11;
            this.listBox6.SelectedIndexChanged += new System.EventHandler(this.listBox6_SelectedIndexChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(38, 150);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(59, 18);
            this.label56.TabIndex = 10;
            this.label56.Text = "Allergien";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(210, 9);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(104, 29);
            this.label52.TabIndex = 0;
            this.label52.Text = "Allergie";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Roboto Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(250, 605);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(135, 18);
            this.label58.TabIndex = 55;
            this.label58.Text = "gelöschte Mitarbeiter:";
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Red;
            this.label61.Location = new System.Drawing.Point(727, 434);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(14, 15);
            this.label61.TabIndex = 56;
            this.label61.Text = "*";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.Color.Red;
            this.label62.Location = new System.Drawing.Point(544, 436);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(14, 15);
            this.label62.TabIndex = 57;
            this.label62.Text = "*";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.Red;
            this.label63.Location = new System.Drawing.Point(216, 484);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(14, 15);
            this.label63.TabIndex = 58;
            this.label63.Text = "*";
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button11.Font = new System.Drawing.Font("Roboto Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.Black;
            this.button11.Location = new System.Drawing.Point(12, 684);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(126, 36);
            this.button11.TabIndex = 59;
            this.button11.Text = "Zurück";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Font = new System.Drawing.Font("Roboto Condensed", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Red;
            this.label67.Location = new System.Drawing.Point(945, 705);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(126, 15);
            this.label67.TabIndex = 60;
            this.label67.Text = "* nicht Pflichtfelder";
            // 
            // Patientenverwaltung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1584, 732);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.Allergiepanel);
            this.Controls.Add(this.Befundepanel);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.Hinzufuege);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Patientenverwaltung";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Patientenverwaltung_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Hinzufuege.ResumeLayout(false);
            this.Hinzufuege.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Befundepanel.ResumeLayout(false);
            this.Befundepanel.PerformLayout();
            this.Allergiepanel.ResumeLayout(false);
            this.Allergiepanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel Hinzufuege;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button AbbrechenPatient;
        private System.Windows.Forms.Button HinzufuegePatient;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel Befundepanel;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Button befundinsert;
        private System.Windows.Forms.Button befunddelete;
        private System.Windows.Forms.Button Updatebefund;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Panel Allergiepanel;
        private System.Windows.Forms.ListBox listBox6;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label67;
    }
}
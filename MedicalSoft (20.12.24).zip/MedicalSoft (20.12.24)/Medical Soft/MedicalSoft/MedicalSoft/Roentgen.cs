﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
namespace MedicalSoft
{
    public partial class Roentgen : Form
    {

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;


        int Patientnr;
        string PatientName;
        string PatientVorname;

        public Roentgen(int PNR, string Pname, string Pvorname)
        {
            InitializeComponent();

            Patientnr = PNR;
            PatientName = Pname;
            PatientVorname = Pvorname;

            label2.Text = PNR.ToString();
            label15.Text = Pname;
            label16.Text = Pvorname;

            textBox1.ReadOnly = true;
            textBox4.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox6.ReadOnly = true;

            groupBox2.Visible = false;



        }

        private void Roentgen_Load(object sender, EventArgs e)
        {
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }



            roentgenverzeichnislistbox();

        }




        void roentgenverzeichnislistbox()
        {
            try
            {


                cmd.CommandText = "SELECT R_ID, R_Bezeichnung FROM Roentgen WHERE R_P_ID =" + label2.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox2.Items.Clear();

                while (dr.Read())
                {
                    string item = dr.GetInt32(0).ToString() + " - " + dr.GetString(1);
                    listBox2.Items.Add(item);


                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("f" + a);
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {


            roentgenbildlistbox();


            try
            {
                if (listBox2.SelectedItem == null || listBox2.SelectedIndex == -1) return;
                string selectedItem = listBox2.SelectedItem.ToString();

                string[] parts = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None);

                string idString = parts[0];


                int selectedID = int.Parse(idString);


                dr.Close();
                cmd.CommandText = "select R_ID, R_Bezeichnung, R_Diagnose, R_Datum from Roentgen where R_ID = " + selectedID;

                dr = cmd.ExecuteReader();

                dr.Read();

                textBox1.Text = dr.GetInt32(0).ToString();
                textBox2.Text = dr.GetString(1);
                richTextBox1.Text = dr.GetString(2);
                dateTimePicker1.Value = dr.GetDateTime(3);

                dr.Close();


            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }



        }

       

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (groupBox2.Visible == false)
            {
                groupBox2.Visible = true;
                autoroentgen();
            }
            else
            {
                groupBox2.Visible = false;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {




                if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(richTextBox2.Text) || dateTimePicker2.Value > DateTime.Today)
                {
                    MessageBox.Show("Bitte geben Sie gültige Werte ein!", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                cmd.CommandText = "insert into Roentgen (R_ID, R_Bezeichnung, R_Diagnose, R_Datum, R_P_ID) values (" + textBox4.Text + ", '" + textBox3.Text + "', '" + richTextBox2.Text + "', '" + dateTimePicker2.Value + "', " + label2.Text.ToString() + ")";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sie haben ein neues Roentgenverzeichnis angelegt", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                roentgenverzeichnislistbox();

                textBox3.Clear();
                textBox4.Clear();
                richTextBox2.Clear();
                dateTimePicker2.Value = DateTime.Today;

                groupBox2.Visible = false;


            }
            catch (Exception a)
            {

                MessageBox.Show("Bitte wählen Sie eine Patienten ID aus um den Mitarbeiter hinzufügen zu können", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void autoroentgen()
        {
            try
            {
                cmd.CommandText = "select max(R_ID)+1 from Roentgen";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox4.Text = dr.GetInt32(0).ToString();

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "") return;

                if (dateTimePicker1.Value > DateTime.Today)
                {
                    MessageBox.Show("Sie müssen ein gültiges Datum angeben!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                cmd.CommandText = "Update Roentgen set R_Bezeichnung = '" + textBox2.Text + "', R_Diagnose = '" + richTextBox1.Text + "', R_Datum = '" + dateTimePicker1.Value + "' WHERE R_id = " + textBox1.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Der Mitarbeiter wurde erfolgreich geupdatet", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception a)
            {

                MessageBox.Show("" + a);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox1.Text == "") return;

                if (MessageBox.Show("Wollen Sie dieses Röntgen wirklich Löschen ?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    cmd.CommandText = "DELETE FROM Roentgen WHERE R_ID = " + listBox2.SelectedItem;
                    cmd.ExecuteNonQuery();

                    roentgenverzeichnislistbox();

                    textBox1.Clear();
                    textBox2.Clear();
                    richTextBox1.Clear();
                    dateTimePicker1.Value = DateTime.Today;


                }

            }
            catch (Exception a)
            {

                MessageBox.Show("" + a);
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listBox3.SelectedItem != null)
                {
                    cmd.CommandText = "SELECT RB_Bild from Roentgenbild WHERE RB_ID = " + listBox3.SelectedItem;
                    cmd.Connection = con;

                    dr = cmd.ExecuteReader();

                    if(dr.Read())
                    {
                        pictureBox1.Load(dr["RB_Bild"].ToString());
                    }
                    dr.Close();



                }
            }
            catch (Exception a)
            {
                
                MessageBox.Show("Test" +a);
            }

        }




        void roentgenbildlistbox()
        {

            try
            {


                if (listBox2.SelectedItem == null)
                {
                    MessageBox.Show("Bitte wählen Sie ein Element aus der Liste aus.");
                    return;
                }
                // Splitten der ID
                string selectedItem = listBox2.SelectedItem.ToString();

                string[] parts = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None);

                string idString = parts[0];


                int selectedID = int.Parse(idString);

                // SQL-Abfrage mit Parametern
                cmd.CommandText = "SELECT RB_ID FROM Roentgenbild WHERE RB_R_ID =" + selectedID;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();


                listBox3.Items.Clear();

                while (dr.Read())
                {
                    if (!dr.IsDBNull(0))
                    {
                        listBox3.Items.Add(dr.GetInt32(0).ToString());
                    }
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler: " + a, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Autowertroentgenbild();

            pictureBox1.Image = null;

            OpenFileDialog openFile = new OpenFileDialog();
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(openFile.FileName);

                string filePath = openFile.FileName;

                string fileName = Path.GetFileName(filePath);

           
                textBox6.Text = fileName;
            }
        }


        void Autowertroentgenbild()
        {
            try
            {
                cmd.CommandText = "select max(RB_ID)+1 from Roentgenbild";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox5.Text = dr.GetInt32(0).ToString();

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }


        private void button6_Click(object sender, EventArgs e)
        {
            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Bitte uploaden Sie erst ein Bild um fortfahren zu können", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                cmd.CommandText = "insert into roentgenbild (RB_ID, RB_R_ID, RB_Bild) values (" + textBox5.Text + ", " + textBox1.Text + " , '" + textBox6.Text + "')";
                cmd.ExecuteNonQuery();

                roentgenbildlistbox();

                textBox5.Clear();
                textBox6.Clear();

                MessageBox.Show("Sie haben dem Patienten ein neues Roentgenbild hinzugefügt!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception a)
            {


                MessageBox.Show("Bitte wählen Sie zuerst ein angelegts Roentgen aus.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}

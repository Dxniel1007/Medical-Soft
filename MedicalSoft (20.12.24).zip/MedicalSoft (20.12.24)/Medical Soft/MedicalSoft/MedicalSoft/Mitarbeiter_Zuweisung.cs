﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Mitarbeiter_Zuweisung : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;
        DataSet dataset = new DataSet();
        OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter();
        DataTable dt = new DataTable();

        int newOperationID;
        string newQualifikationID;
        public Mitarbeiter_Zuweisung(int OperationID, string QualifikationID)
        {
            InitializeComponent();
            newOperationID = OperationID;
            newQualifikationID = QualifikationID;
        }

        void FillDataGrid()
        {
            try
            {

                cmd.CommandText = "Select M_ID, M_Name, M_Vorname, MQ_Q_ID from Mitarbeiter, Mitarbeiter_Qualifikationen where M_ID = MQ_M_ID and MQ_Q_ID = " + newQualifikationID;
                cmd.Connection = con;

                oleDbDataAdapter.SelectCommand = cmd;
                dt.Clear();
                oleDbDataAdapter.Fill(dt);
                dataGridView1.DataSource = dt;

                dataGridView1.Columns[0].HeaderCell.Value = "Mitarbeiter-ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Mitarbeiter-Name";
                dataGridView1.Columns[2].HeaderCell.Value = "Mitarbeiter-Vorname";
                dataGridView1.Columns[3].HeaderCell.Value = "Qualifikation-ID";
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void Mitarbeiter_Zuweisung_Load(object sender, EventArgs e)
        {
            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox1.Text = newOperationID.ToString();
            //textBox2.Text = newQualifikationID;

            // Datenbank-Verbindung herstellen
            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";
                con.Open();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }

            try
            {
                cmd.CommandText = "Select Q_Bezeichnung from Qualifikation where Q_ID = " + newQualifikationID;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox2.Text = dr.GetString(0);

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }

            FillDataGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte wählen Sie die ganze Zeile aus, um einen Mitarbeiter der Operation " + newOperationID + " zuweisen zu können.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }
    }
}

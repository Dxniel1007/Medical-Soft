﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Krankenversicherung : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;
        DataSet dataset = new DataSet();
        OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter();
        DataTable dt = new DataTable();
        public Krankenversicherung()
        {
            InitializeComponent();
            textBox1.TextChanged += textBox1_TextChanged_1;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Krankenversicherung_Load(object sender, EventArgs e)
        {
            textBox2.ReadOnly = true;
            textBox9.ReadOnly = true;
            panel1.Visible = false;

            comboBox2.Items.Add("Krankenkasse-ID");
            comboBox2.Items.Add("Kassennummer");
            comboBox2.Items.Add("Name");
            comboBox2.Items.Add("Straße");
            comboBox2.Items.Add("Hausnummer");
            comboBox2.Items.Add("Stadt");
            comboBox2.Items.Add("Gesetzlich");
            comboBox2.Items.Add("IBAN");

            comboBox2.SelectedIndex = 0;

            // Datenbank-Verbindung herstellen
            try
            {

                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";
                con.Open();

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }

            // Methode zum Füllen des DataGridViews 
            FillDataGridView();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form H = new Form2(System.Convert.ToString(textBox1.Text));
            this.Hide();
            H.ShowDialog();
        }

        void MaxKV_ID()
        {
            try
            {
                cmd.CommandText = "Select max(KV_ID) +1 from Krankenversicherung";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();
                dr.Read();

                textBox2.Text = dr.GetInt32(0).ToString();
                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel1.Visible = true;
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;

            // Selektieren der max(KV_ID) zum Hinzufügen einer neuen Krankenversicherung
            // Kann vom Benutzer nicht verändert werden, sie wird festegelegt
            MaxKV_ID();
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            // Methode zum Anzeigen der Daten in den jeweiligen TextBoxen
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie ganz links auf die Zeile um sich die ausgewählten Informationen anzeigen zu lassen.");

            }
            else
            {
                try
                {

                    string ID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    string Kassennummer = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    string Name = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    string Straße = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                    string Hausnummer = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                    string Stadt = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                    string Gesetzlich = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                    string IBAN = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();

                    textBox9.Text = ID;
                    textBox10.Text = Kassennummer;
                    textBox11.Text = Name;
                    textBox12.Text = Straße;
                    textBox13.Text = Hausnummer;
                    textBox14.Text = Stadt;
                    textBox15.Text = IBAN;
                    comboBox1.Text = Gesetzlich;



                }
                catch (Exception a)
                {

                    MessageBox.Show("Fehler" + a);
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Abfrage zum Abbrechen beim Hinzufügen einer neuen Krankenversicherung
            DialogResult dialogResult = MessageBox.Show("Wollen Sie wirklich das Hinzufügen einer Krankenversicherung abbrechen? Es gehen alle bereits eingegebenen Daten verloren!", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (dialogResult == DialogResult.Yes)
            {
                panel1.Visible = false;
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                radioButton1.Checked = false;
                radioButton2.Checked = false;

            }
            else
            {
                panel1.Visible = true;
            }

        }

        /// <summary>
        /// Update Krankenversicherung
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            string suchtext = textBox1.Text.Trim();
            if (textBox9.Text == "")
            {
                MessageBox.Show("Sie haben keine Daten ausgewählt, daher kann keine Bearbeitung stattfinden.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Bitte bestätigen Sie das Bearbeiten der ausgewählten Krankenversicherung ", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dialogResult == DialogResult.Yes)
                {
                    if (string.IsNullOrEmpty(textBox10.Text) || string.IsNullOrEmpty(textBox11.Text) || string.IsNullOrEmpty(textBox12.Text) || string.IsNullOrEmpty(textBox13.Text) || string.IsNullOrEmpty(textBox14.Text) || string.IsNullOrEmpty(textBox15.Text) || comboBox1.SelectedIndex == -1)
                    {
                        comboBox1.SelectedIndex = 0;
                        MessageBox.Show("Sie müssen jegliche Informationen zur Krankenversicherung angeben, bitte überprüfen Sie Ihre Eingabe.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        if (!int.TryParse(textBox13.Text, out int HausNr) || !int.TryParse(textBox10.Text, out int KassenNr) || !int.TryParse(textBox15.Text, out int IBAN))
                        {

                            MessageBox.Show("Ungültiger Wert in den Eingabefeldern", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                        else
                        {
                            try
                            {
                                cmd.CommandText = "Update Krankenversicherung set KV_Kassennummer = " + KassenNr + ", KV_Name = '" + textBox11.Text + "', KV_Straße = '" + textBox12.Text + "', KV_Hausnummer = " + HausNr + ", KV_Stadt = '" + textBox14.Text + "', KV_IBAN = " + IBAN + ", KV_Gesetzlich = '" + comboBox1.Text + "' where KV_ID = " + textBox9.Text;
                                cmd.ExecuteNonQuery();

                                FillDataGridView();
                                FilterData(suchtext);

                                textBox9.Clear();
                                textBox10.Clear();
                                textBox11.Clear();
                                textBox12.Clear();
                                textBox13.Clear();
                                textBox14.Clear();
                                textBox15.Clear();
                                comboBox1.SelectedIndex = -1;


                                MessageBox.Show("Krankenversicherung wurde erfolgreich bearbeitet.");
                            }
                            catch (Exception a)
                            {
                                MessageBox.Show("Die Daten der ausgewählten Krankenversicherung konnten nicht bearbeitet werden." + a, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Methode zum Füllen des DataGridViews mit allen zugehörigen Attributen der Tabelle Krankenversicherung
        /// </summary>
        void FillDataGridView()
        {
            try
            {
                cmd.CommandText = "Select KV_ID, KV_Kassennummer, KV_Name, KV_Straße, KV_Hausnummer, KV_Stadt, KV_Gesetzlich, KV_IBAN from Krankenversicherung";
                cmd.Connection = con;

                oleDbDataAdapter.SelectCommand = cmd;
                dt.Clear();
                oleDbDataAdapter.Fill(dt);

                dataGridView1.DataSource = dt;


                //dataset.Clear();

                //oleDbDataAdapter.Fill(dataset, "Filter");
                //dataGridView1.DataSource = dataset;
                //dataGridView1.DataMember = "Filter";


                dataGridView1.Columns[0].HeaderCell.Value = "Krankenkasse-ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Kassennummer";
                dataGridView1.Columns[2].HeaderCell.Value = "Name";
                dataGridView1.Columns[3].HeaderCell.Value = "Straße";
                dataGridView1.Columns[4].HeaderCell.Value = "Hausnummer";
                dataGridView1.Columns[5].HeaderCell.Value = "Stadt";
                dataGridView1.Columns[6].HeaderCell.Value = "Gesetzlich?";
                dataGridView1.Columns[7].HeaderCell.Value = "IBAN";
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            string suchtext = textBox1.Text.Trim();
            FilterData(suchtext);
        }

        /// <summary>
        /// Methode zum Filtern von Datensätzen nach bestimmten Attributen aus dem DataGridView
        /// Als Parameter wird der string suchtext übergeben, welcher den Inhalt der textBox behinhaltet
        /// </summary>
        /// <param name="suchtext"></param>
        void FilterData(string suchtext)
        {
            try
            {
                if (comboBox2.SelectedIndex == -1 || comboBox2.SelectedItem == null)
                {
                    comboBox2.SelectedIndex = 0;
                    MessageBox.Show("Bitte wählen Sie ein gültiges Suchkriterium aus der Liste aus.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {

                    string selectedColumn = comboBox2.SelectedItem.ToString();

                    DataView dv = new DataView(dt); // DataView verwenden, um den Filter anzuwenden

                    if (string.IsNullOrEmpty(suchtext))
                    {
                        // Wenn das Textfeld bzw. die TextBox leer ist, werden alle Daten wieder angezeigt
                        dv.RowFilter = string.Empty;

                    }
                    else if (!string.IsNullOrEmpty(selectedColumn))
                    {
                        // Filterung nach der ausgewählten Spalte => hier: Krankenkasse-ID
                        if (selectedColumn == "Krankenkasse-ID")
                        {
                            // Wenn nach der Krankenkassen-ID gesucht wird, werden nur Einträge angezeigt die mit dem Suchtext anfangen
                            dv.RowFilter = $"Convert(KV_ID, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Kassennummer")
                        {
                            dv.RowFilter = $"Convert(KV_Kassennummer, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Name")
                        {
                            dv.RowFilter = $"KV_Name LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Straße")
                        {
                            dv.RowFilter = $"KV_Straße LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Hausnummer")
                        {
                            dv.RowFilter = $"Convert(KV_Hausnummer, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Stadt")
                        {
                            dv.RowFilter = $"KV_Stadt LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Gesetzlich")
                        {
                            dv.RowFilter = $"Convert(KV_Gesetzlich, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "IBAN")
                        {
                            dv.RowFilter = $"Convert(KV_IBAN, 'System.String') LIKE '{suchtext}%'";
                        }


                    }


                    // Gefiltertes DataView als Datenquelle setzen
                    dataGridView1.DataSource = dv;
                }

            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        /// <summary>
        /// Delete Krankenversicherung
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            string suchtext = textBox1.Text.Trim();
            if (textBox9.Text == "")
            {
                MessageBox.Show("Sie haben keine Daten ausgewählt, daher kann kein Löschen der Daten erfolgen.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                try
                {
                    DialogResult dialogResult = MessageBox.Show("Möchten Sie wirklich die ausgewählte Krankenversicherung löschen?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (dialogResult == DialogResult.Yes)
                    {

                        cmd.CommandText = "Delete * from Krankenversicherung where KV_ID = " + textBox9.Text;
                        cmd.Connection = con;
                        cmd.ExecuteNonQuery();

                        textBox9.Clear();
                        textBox10.Clear();
                        textBox11.Clear();
                        textBox12.Clear();
                        textBox13.Clear();
                        textBox14.Clear();
                        textBox15.Clear();
                        comboBox1.SelectedIndex = -1;

                        FillDataGridView();
                        FilterData(suchtext);
                        MaxKV_ID();

                        MessageBox.Show("Krankenversicherung wurde erfolgreich entfernt.");
                    }

                }
                catch (Exception a)
                {
                    MessageBox.Show("Krankenversicherung konnte nichte gelöscht werden." + a, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            comboBox2.SelectedIndex = 0;
        }

        /// <summary>
        /// Insert Krankenversicherung
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "" || radioButton1.Checked == false && radioButton2.Checked == false)
                {
                    MessageBox.Show("Bitte füllen Sie alle Felder aus oder korrigieren Sie gegebenfalls ihre Eingabe bezüglich falsch eingetragener Werte.", "Hinweis", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Gesetzlich: Ja
                    if (radioButton1.Checked)
                    {
                        cmd.CommandText = "Insert into Krankenversicherung (KV_ID, KV_Kassennummer, KV_Name, KV_Straße, KV_Hausnummer, KV_Stadt, KV_Gesetzlich, KV_IBAN) values (" + textBox2.Text + ", " + textBox3.Text + ", '" + textBox4.Text + "', '" + textBox5.Text + "', " + textBox6.Text + ", '" + textBox7.Text + "', '" + radioButton1.Text + "', " + textBox8.Text + ")";
                    }
                    // Gesetzlich: Nein
                    else if (radioButton2.Checked)
                    {
                        cmd.CommandText = "Insert into Krankenversicherung (KV_ID, KV_Kassennummer, KV_Name, KV_Straße, KV_Hausnummer, KV_Stadt, KV_Gesetzlich, KV_IBAN) values (" + textBox2.Text + ", " + textBox3.Text + ", '" + textBox4.Text + "', '" + textBox5.Text + "', " + textBox6.Text + ", '" + textBox7.Text + "', '" + radioButton2.Text + "', " + textBox8.Text + ")";
                    }

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    FillDataGridView();
                    panel1.Visible = false;

                    MessageBox.Show("Neue Krankenversicherung wurde hinzugefügt.");
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Krankenversicherung konnte nicht hinzugefügt werden, da Sie möglicherweise eine falsche Eigabe getätigt haben.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        /// <summary>
        /// Eingabe löschen bei Hinzufügen einer neuen Krankenversicherung
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Mitarbeiter : Form
    {
        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        OleDbDataReader dr = null;
        DataTable dt = new DataTable();


        public Mitarbeiter()
        {
            InitializeComponent();
            textBox6.ReadOnly = true;
            textBox1.ReadOnly = true;

            comboBox3.SelectedItem = "ID";

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Sie müssen etwas eingeben", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {

                    dr.Close();
                    cmd.CommandText = "INSERT into Mitarbeiter (M_ID, M_Name, M_Vorname, M_Passwort, M_Rechte) values (" + textBox1.Text + ", '" + textBox2.Text + "' , '" + textBox3.Text + "', '" + textBox4.Text + "', '" + comboBox1.SelectedItem + "')";
                    cmd.Connection = con;

                    dr = cmd.ExecuteReader();

                    MessageBox.Show(" Es wurde ein neuer Mitarbeiter hinzugefügt");
                    dr.Close();

                    Filldatagrid();
                }
                catch (Exception a)
                {

                    MessageBox.Show("f" + a);
                }



                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                M_ID();
            }


        }

        private void Mitarbeiter_Load(object sender, EventArgs e)
        {


            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }

            Filldatagrid();

            try
            {
                cmd.CommandText = "select M_ID, M_Name from Mitarbeiter where M_Gelöscht = true";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();



                while (dr.Read())
                {
                    listBox2.Items.Add(dr.GetInt32(0));
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Fehler");
                this.Close();
            }


            dr.Close();

            M_ID();





        }

        void M_ID()
        {
            try
            {
                cmd.CommandText = "Select max(M_ID)+1 from Mitarbeiter ";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                dr.Read();

                textBox1.Text = (dr.GetInt32(0).ToString());
                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("Fehler" + a);

            }
        }

        void Filldatagrid()
        {
            try
            {


                cmd.CommandText = "Select M_ID, M_Name, M_Vorname, M_Passwort, M_Rechte from Mitarbeiter where M_Gelöscht = false";
                cmd.Connection = con;

                da.SelectCommand = cmd;

                dt.Clear();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                /* ds.Clear();

                 da.Fill(ds, "Kundenfilter");
                 dataGridView1.DataSource = ds;
                 dataGridView1.DataMember = "Kundenfilter";*/

                dataGridView1.Columns[0].HeaderCell.Value = "Nummer";
                dataGridView1.Columns[1].HeaderCell.Value = "Name";
                dataGridView1.Columns[2].HeaderCell.Value = "Vorname";
                dataGridView1.Columns[3].HeaderCell.Value = "Passwort";
                dataGridView1.Columns[4].HeaderCell.Value = "Rechte";







            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie links auf die ganze Zeile ");

            }
            else
            {


                try
                {



                    string Nummer = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                    string Name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

                    string Vorname = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

                    string Passwort = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

                    string Rechte = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();







                    textBox6.Text = Nummer;
                    textBox7.Text = Name;
                    textBox8.Text = Vorname;
                    textBox9.Text = Passwort;
                    comboBox2.Text = Rechte;



                    listboxupdate();



                }
                catch (Exception a)
                {

                    MessageBox.Show("Fehler " + a);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string suchtext = textBox5.Text.Trim();


            try
            {
                if (string.IsNullOrEmpty(textBox6.Text))
                {
                    MessageBox.Show("Es wurde kein Mitarbeiter zum Updaten ausgewählt", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    dr.Close();
                    cmd.CommandText = "Update Mitarbeiter set M_Name = '" + textBox7.Text + "' , M_Vorname= '" + textBox8.Text + "' , M_Passwort='" + textBox9.Text + "' , M_Rechte = '" + comboBox2.SelectedItem + "' where M_ID = " + textBox6.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Der Mitarbeiter wurde erfolgreich geupdatet!");

                    Filldatagrid();
                    suchfiltern(suchtext);
                    dr.Close();

                }





            }
            catch (Exception a)
            {

                MessageBox.Show("Fhelr" + a);
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dr.Close();
                cmd.CommandText = "select MQ_Q_ID from Mitarbeiter_Qualifikationen where MQ_M_ID = " + textBox6.Text;
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0).ToString());
                }

                dr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler" + ex.Message);
                this.Close();
            }

        }

        void listboxupdate()
        {
            try
            {
                dr.Close();
                cmd.CommandText = "select MQ_Q_ID from Mitarbeiter_Qualifikationen where MQ_M_ID = " + textBox6.Text;
                cmd.Connection = con;

                dr = cmd.ExecuteReader();
                listBox1.Items.Clear();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0).ToString());
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                dr.Close();

                cmd.CommandText = " Select Q_Bezeichnung from Qualifikation where Q_ID =" + listBox1.SelectedItem;

                dr = cmd.ExecuteReader();

                dr.Read();



                label15.Text = (dr.GetString(0));



                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
                this.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                if (textBox6.Text == "")
                {
                    MessageBox.Show("Es wurde kein Mitarbeiter zum Löschen ausgewählt ! ", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    dr.Close();
                    cmd.CommandText = "Update Mitarbeiter set M_Gelöscht = true where M_ID = " + textBox6.Text;
                    cmd.Connection = con;

                    cmd.ExecuteNonQuery();

                    Filldatagrid();
                    rückgängig();

                    MessageBox.Show("Der Mitarbeiter wurde gelöscht");

                    dr.Close();
                }


            }
            catch (Exception a)
            {
                MessageBox.Show("f" + a);

            }
            textBox5.Clear();

            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();



        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void button6_Click(object sender, EventArgs e)
        {
            try
            {

                if (listBox2.SelectedItem != null)
                {
                    dr.Close();
                    cmd.CommandText = "Update Mitarbeiter set M_Gelöscht = false where M_ID = " + listBox2.SelectedItem;
                    cmd.Connection = con;

                    cmd.ExecuteNonQuery();

                    Filldatagrid();

                    rückgängig();
                    listBox2.Items.Remove(listBox2.SelectedItem);

                    MessageBox.Show("Sie haben den Mitarbeiter Rückgängig gemacht", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Sie haben keinen gelöschten Mitarbeiter ausgewählt", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            catch (Exception A)
            {

                MessageBox.Show("f" + A);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            M_ID();

        }
        void rückgängig()
        {

            try
            {
                cmd.CommandText = "select M_ID from Mitarbeiter where M_Gelöscht = true";
                cmd.Connection = con;

                dr = cmd.ExecuteReader();

                listBox1.Items.Clear();

                while (dr.Read())
                {
                    listBox2.Items.Add(dr.GetInt32(0));
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Fehler");
                this.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Q = new Qualifikationen();
            this.Hide();
            Q.ShowDialog();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string suchtext = textBox5.Text.Trim();
            suchfiltern(suchtext);
        }

        void suchfiltern(string suchtext)
        {

            try
            {

                if (comboBox3.SelectedIndex == -1 || comboBox3.SelectedItem == null)
                {
                    comboBox3.SelectedIndex = 0;
                    MessageBox.Show("Bitte wählen Sie einen gültigen Wert aus der Liste aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {
                    string selectedColumn = comboBox3.SelectedItem.ToString();
                    DataView dv = new DataView(dt); // DataView verwenden, um den Filter anzuwenden

                    if (string.IsNullOrEmpty(suchtext))
                    {
                        // Wenn das Textfeld bzw. die TextBox leer ist, werden alle Daten wieder angezeigt
                        dv.RowFilter = string.Empty;

                    }
                    else if (!string.IsNullOrEmpty(selectedColumn))
                    {


                        // Filterung nach der ausgewählten Spalte => hier: Krankenkasse-ID
                        if (selectedColumn == "ID")
                        {
                            // Wenn nach der Krankenkassen-ID gesucht wird, werden nur Einträge angezeigt die mit dem Suchtext anfangen
                            dv.RowFilter = $"Convert(M_ID, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Name")
                        {
                            dv.RowFilter = $"Convert(M_Name, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Vorname")
                        {
                            dv.RowFilter = $"M_Vorname LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Passwort")
                        {
                            dv.RowFilter = $"M_Passwort LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Rechte")
                        {
                            dv.RowFilter = $"Convert(M_Rechte, 'System.String') LIKE '{suchtext}%'";
                        }

                    }


                    // Gefiltertes DataView als Datenquelle setzen
                    dataGridView1.DataSource = dv;
                }




            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form H = new Form2(System.Convert.ToString(textBox1.Text));
            this.Hide();
            H.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

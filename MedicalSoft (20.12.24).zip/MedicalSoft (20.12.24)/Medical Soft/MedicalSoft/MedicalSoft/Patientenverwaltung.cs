﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace MedicalSoft
{
    public partial class Patientenverwaltung : Form
    {

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        OleDbDataReader dr = null;
        DataTable dt = new DataTable();


        public Patientenverwaltung()
        {
            InitializeComponent();
            Hinzufuege.Visible = false;
            Befundepanel.Visible = false;
            Allergiepanel.Visible = false;


            textBox2.ReadOnly = true;
            textBox19.ReadOnly = true;
            textBox36.ReadOnly = true;

            textBox34.ReadOnly = true;


            button9.Visible = false;





        }

        private void Patientenverwaltung_Load(object sender, EventArgs e)
        {

            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }

            datafill();

            listboxfill();

            KrankenkassenIDs();






            if (textBox17.Text == "")
            {

            }
            else
            {
                KV();
            }


        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        void KV()
        {
            try
            {
                cmd.CommandText = "Select KV_Name from Krankenversicherung where KV_ID = " + textBox17.Text;
                dr = cmd.ExecuteReader();

                dr.Read();

                label43.Text = dr.GetString(0);

                dr.Close();
            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);

            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        void KrankenkassenIDs()
        {
            try
            {
                cmd.CommandText = "Select KV_ID from Krankenversicherung";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                comboBox4.Items.Clear();

                while (dr.Read())
                {
                    comboBox4.Items.Add(dr.GetInt32(0));
                }

                dr.Close();


            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {


            if (Hinzufuege.Visible == false)
            {
                Hinzufuege.Visible = true;
                Befundepanel.Visible = false;
                Auto();
            }
            else
            {
                Hinzufuege.Visible = false;
            }
        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void Hinzufuege_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label38_Click(object sender, EventArgs e)
        {

        }

        void datafill()
        {
            try
            {
                cmd.CommandText = "Select P_ID, P_Name, P_Vorname, P_Geburtsdatum, P_Geschlecht, P_Größe, P_Gewicht, P_Blutgruppe, P_Telefon, P_Handy, P_Email, P_Straße, P_Hausnummer, P_PLZ, P_Stadt, P_Land, P_IBAN, P_KV_ID, P_Versichertennummer from Patient where P_Gelöscht = false";
                cmd.Connection = con;

                da.SelectCommand = cmd;
                dt.Clear();
                da.Fill(dt);

                dataGridView1.DataSource = dt;





                dataGridView1.Columns[0].HeaderCell.Value = "Patient-ID";
                dataGridView1.Columns[1].HeaderCell.Value = "Name";
                dataGridView1.Columns[2].HeaderCell.Value = "Vorname";
                dataGridView1.Columns[3].HeaderCell.Value = "Geburtsdatum";
                dataGridView1.Columns[4].HeaderCell.Value = "Geschlecht";
                dataGridView1.Columns[5].HeaderCell.Value = "Größe";
                dataGridView1.Columns[6].HeaderCell.Value = "Gewicht";
                dataGridView1.Columns[7].HeaderCell.Value = "Blutgruppe";
                dataGridView1.Columns[8].HeaderCell.Value = "Telefon";
                dataGridView1.Columns[9].HeaderCell.Value = "Handy-Tel";
                dataGridView1.Columns[10].HeaderCell.Value = "E-mail";
                dataGridView1.Columns[11].HeaderCell.Value = "Straße";
                dataGridView1.Columns[12].HeaderCell.Value = "Haus-Nr";
                dataGridView1.Columns[13].HeaderCell.Value = "PLZ";
                dataGridView1.Columns[14].HeaderCell.Value = "Stadt";
                dataGridView1.Columns[15].HeaderCell.Value = "Land";
                dataGridView1.Columns[16].HeaderCell.Value = "IBAN";
                dataGridView1.Columns[17].HeaderCell.Value = "Krankenversicherungs Nr";
                dataGridView1.Columns[18].HeaderCell.Value = "Versichertennummer";


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie links auf die ganze Zeile ");

            }
            else
            {
                try
                {
                    string ID = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                    string Name = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    string Vorname = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    DateTime GB = (DateTime)dataGridView1.SelectedRows[0].Cells[3].Value;
                    string Geschlecht = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                    string Größe = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                    string Gewicht = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                    string Blutgruppe = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
                    string Telefon = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
                    string Handy = dataGridView1.SelectedRows[0].Cells[9].Value.ToString();
                    string email = dataGridView1.SelectedRows[0].Cells[10].Value.ToString();
                    string straße = dataGridView1.SelectedRows[0].Cells[11].Value.ToString();
                    string hausnr = dataGridView1.SelectedRows[0].Cells[12].Value.ToString();
                    string PLZ = dataGridView1.SelectedRows[0].Cells[13].Value.ToString();
                    string Stadt = dataGridView1.SelectedRows[0].Cells[14].Value.ToString();
                    string Land = dataGridView1.SelectedRows[0].Cells[15].Value.ToString();
                    string IBAN = dataGridView1.SelectedRows[0].Cells[16].Value.ToString();
                    string KVNR = dataGridView1.SelectedRows[0].Cells[17].Value.ToString();
                    string Versichertennr = dataGridView1.SelectedRows[0].Cells[18].Value.ToString();

                    //für die ID übertragung bei Befund
                    label57.Text = ID;
                    textBox34.Text = Name;


                    //für die ID übertragung bei Allergie

                    label54.Text = ID;
                    label55.Text = Name;

                    textBox2.Text = ID;
                    textBox3.Text = Name;
                    textBox4.Text = Vorname;
                    dateTimePicker1.Value = GB;
                    comboBox2.Text = Geschlecht;
                    textBox5.Text = Größe;
                    textBox6.Text = Gewicht;
                    textBox7.Text = Blutgruppe;
                    textBox8.Text = Telefon;
                    textBox9.Text = Handy;
                    textBox10.Text = email;
                    textBox11.Text = straße;
                    textBox12.Text = hausnr;
                    textBox13.Text = PLZ;
                    textBox14.Text = Stadt;
                    textBox15.Text = Land;
                    textBox16.Text = IBAN;
                    textBox17.Text = KVNR;
                    textBox18.Text = Versichertennr;

                    dr.Close();

                    KV();


                    BEFUNDELISTBOX();
                    ALLERGIENLISTBOX();
                }
                catch (Exception a)
                {

                    MessageBox.Show("Bitte klicken Sie einen bereits vorhandenen Datensatz aus.", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {


                if (string.IsNullOrEmpty(textBox2.Text))
                {
                    MessageBox.Show("Sie haben keinen Patienten ausgewählt!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Überprüfen, ob Pflichtfelder leer sind
                if (string.IsNullOrEmpty(textBox3.Text.Trim()) || string.IsNullOrEmpty(textBox4.Text.Trim()) ||
                 string.IsNullOrEmpty(comboBox2.Text.Trim()) || string.IsNullOrEmpty(textBox7.Text.Trim()) ||
                 string.IsNullOrEmpty(textBox11.Text.Trim()) || string.IsNullOrEmpty(textBox14.Text.Trim()) ||
                 string.IsNullOrEmpty(textBox15.Text.Trim()))
                {
                    MessageBox.Show("Bitte füllen Sie alle erforderlichen Felder aus!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //zahlwerten gleich 0 setzten
                if (string.IsNullOrEmpty(textBox8.Text))
                {
                    textBox8.Text = "0";

                }

                if (string.IsNullOrEmpty(textBox9.Text))
                {
                    textBox9.Text = "0";

                }

                if (string.IsNullOrEmpty(textBox10.Text))
                {
                    textBox10.Text = "0";

                }

                // Überprüfen, ob numerische Felder gültige Zahlen enthalten
                if (!int.TryParse(textBox5.Text, out int Größe) || !int.TryParse(textBox8.Text, out int TELE) || !int.TryParse(textBox9.Text, out int Handy) || !int.TryParse(textBox6.Text, out int Gewicht) || !int.TryParse(textBox12.Text, out int Hausnr) || !int.TryParse(textBox13.Text, out int PLZ) || !int.TryParse(textBox17.Text, out int KVID) || !int.TryParse(textBox18.Text, out int VSnr) || !int.TryParse(textBox16.Text, out int IBAN))
                {
                    MessageBox.Show("Ungültiger Wert in den Eingabefeldern", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // bestätigung
                if (MessageBox.Show("Wollen Sie den Mitarbeiter wirklich Updaten?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cmd.CommandText = "UPDATE Patient SET P_Name= '" + textBox3.Text + "' , P_Vorname= '" + textBox4.Text + "', P_Geburtsdatum= '" + dateTimePicker1.Value + "', P_Geschlecht = '" + comboBox2.SelectedItem +
                                      "', P_Größe =" + Größe + ", P_Gewicht=" + Gewicht + ", P_Blutgruppe ='" + textBox7.Text + "', " +
                                      "P_Telefon=" + TELE + ", P_Handy= " + Handy + " , P_Email ='" + textBox10.Text + "' , P_Straße='" + textBox11.Text + "', P_Hausnummer = " + Hausnr + ", P_PLZ=" + PLZ + ", P_Stadt='" + textBox14.Text +
                                      "', P_Land = '" + textBox15.Text + "', P_IBAN = " + IBAN + ", P_KV_ID = " + KVID + ", P_Versichertennummer= " + VSnr + " where P_ID = " + textBox2.Text;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();

                    datafill();

                    KV();
                }
            }
            catch (Exception a)
            {

                MessageBox.Show("Bitte wählen Sie eine Vorhandene Krankenkasse aus!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string suchtext = textBox1.Text.Trim();
            suche(suchtext);
        }

        void suche(string suche)
        {
            try
            {
                if (comboBox1.SelectedIndex == -1 || comboBox1.SelectedItem == null)
                {
                    comboBox1.SelectedIndex = 0;
                    MessageBox.Show("Bitte wählen Sie einen gültigen Wert aus der Liste aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {


                    string selectedColumn = comboBox1.SelectedItem.ToString();
                    DataView dv = new DataView(dt); 

                    if (string.IsNullOrEmpty(suche))
                    {
                        dv.RowFilter = string.Empty;

                    }
                    else if (!string.IsNullOrEmpty(selectedColumn))
                    {
                        if (selectedColumn == "ID")
                        {
                            dv.RowFilter = $"Convert(P_ID, 'System.String') LIKE '{suche}%'";
                        }
                        else if (selectedColumn == "Name")
                        {

                            dv.RowFilter = $"Convert(P_Name, 'System.String') LIKE '{suche}%'";
                        }
                        else if (selectedColumn == "Vorname")
                        {
                            dv.RowFilter = $"Convert(P_Vorname, 'System.String') LIKE '{suche}%'";
                        }
                        else if (selectedColumn == "Stadt")
                        {
                            dv.RowFilter = $"Convert(P_Stadt, 'System.String') LIKE '{suche}%'";
                        }
                        else if (selectedColumn == "Land")
                        {
                            dv.RowFilter = $"Convert(P_Land, 'System.String') LIKE '{suche}%'";
                        }
                        else if (selectedColumn == "Straße")
                        {
                            dv.RowFilter = $"Convert(P_Straße, 'System.String') LIKE '{suche}%'";
                        }

                    }



                    dataGridView1.DataSource = dv;
                }


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Bitte wählen Sie einen Mitarbeiter aus um Ihn Löschen zu können!", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
                else
                {

                    if (MessageBox.Show("Wollen Sie den Mitarbeiter wirklich Löschen?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No) return;

                    cmd.CommandText = "UPDATE Patient set P_Gelöscht = true where P_ID = " + textBox2.Text;
                    cmd.ExecuteNonQuery();

                    datafill();
                    listboxfill();

                    textBox2.Clear();
                    textBox3.Clear();
                    textBox4.Clear();
                    textBox5.Clear();
                    textBox6.Clear();
                    textBox7.Clear();
                    textBox8.Clear();
                    textBox9.Clear();
                    textBox10.Clear();
                    textBox11.Clear();
                    textBox12.Clear();
                    textBox13.Clear();
                    textBox14.Clear();
                    textBox15.Clear();
                    textBox16.Clear();
                    textBox17.Clear();
                    textBox18.Clear();
                    label43.Text = "";



                }



            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        void listboxfill()
        {
            try
            {
                cmd.CommandText = "select P_ID from Patient where P_Gelöscht = true";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox1.Items.Clear();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0));
                }

                dr.Close();


            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBox1.SelectedIndex == -1)
                {
                    MessageBox.Show("Sie müssen einen Patienten auswählen um Ihn wieder Rückgängig machen zu können", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    cmd.CommandText = "Update Patient set P_Gelöscht = false where P_ID = " + listBox1.SelectedItem;
                    cmd.ExecuteNonQuery();
                    listboxfill();
                    datafill();
                }

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);

            }
        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {


        }

        private void HinzufuegePatient_Click(object sender, EventArgs e)
        {
            /* try
             {


                 if (dateTimePicker2.Value > DateTime.Today)
                 {
                     MessageBox.Show("Sie können keinen Paienten hinzufügen der nach Heute geboren wurde!", "Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 }



                 cmd.CommandText = "insert into Patient (P_ID, P_Name, P_Vorname, P_Geburtsdatum, P_Geschlecht, P_Größe, P_Gewicht, P_Blutgruppe, P_Telefon," +
                     " P_Handy, P_Email, P_Straße, P_Hausnummer, P_PLZ, P_stadt, p_land, p_iban, p_kv_id, " +
                     "p_versichertennummer) VALUES " +
                     "(" + textBox19.Text + ", '" + textBox20.Text + "', '" + textBox21.Text + "', '" + dateTimePicker2.Value + "', '" + comboBox3.SelectedItem + "', " + textBox22.Text + ", " + textBox23.Text +
                     ", '" + textBox24.Text + "', " + textBox25.Text + ", " + textBox26.Text + ", '" + textBox27.Text + "', '" + textBox28.Text + "', " + textBox29.Text + ", " + textBox30.Text + ", '" + textBox31.Text + "', '" + textBox32.Text + "', " +
                     textBox33.Text + ", " + comboBox4.SelectedItem.ToString() + ", " + textBox35.Text + ")";

                 cmd.ExecuteNonQuery();
                 MessageBox.Show("Sie haben einen neuen Patient hinzugefügt", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);


                 // Neue Zahl bei ID
                 Auto();


                 // textbox leeren

                 textBox20.Clear();
                 textBox21.Clear();
                 comboBox3.SelectedIndex = 0;
                 textBox22.Clear();
                 textBox23.Clear();
                 textBox24.Clear();
                 textBox25.Clear();
                 textBox26.Clear();
                 textBox27.Clear();
                 textBox28.Clear();
                 textBox29.Clear();
                 textBox30.Clear();
                 textBox31.Clear();
                 textBox32.Clear();
                 textBox33.Clear();
                 comboBox1.Text = "";

                 //datagrid updaten

                 datafill();





             }
             catch (Exception a)
             {

                 MessageBox.Show("Ungültige Eingabe Werte!" + a, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

             }*/

            try
            {
                if (dateTimePicker2.Value > DateTime.Today)
                {
                    MessageBox.Show("Sie können keinen Patienten hinzufügen, der nach heute geboren wurde!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Überprüfen, ob Pflichtfelder ausgefüllt sin
                if (string.IsNullOrEmpty(textBox19.Text) || 
                    string.IsNullOrEmpty(textBox20.Text) || 
                    string.IsNullOrEmpty(textBox21.Text) || 
                    string.IsNullOrEmpty(textBox22.Text) ||
                    string.IsNullOrEmpty(textBox23.Text) || 
                    string.IsNullOrEmpty(textBox24.Text) || 
                    string.IsNullOrEmpty(textBox28.Text) || 
                    string.IsNullOrEmpty(textBox29.Text) || 
                    string.IsNullOrEmpty(textBox30.Text) || 
                    string.IsNullOrEmpty(textBox31.Text) || 
                    string.IsNullOrEmpty(textBox32.Text) || 
                    string.IsNullOrEmpty(textBox33.Text) ||
                    string.IsNullOrEmpty(textBox35.Text))   
                {
                    MessageBox.Show("Alle Felder müssen ausgefüllt werden!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Werte aus den Textboxen holen, leere Felder durch Standardwerte ersetzen
                string pID = string.IsNullOrWhiteSpace(textBox19.Text.Trim()) ? "NULL" : textBox19.Text;
                string pName = string.IsNullOrWhiteSpace(textBox20.Text.Trim()) ? "''" : $"'{textBox20.Text}'";
                string pVorname = string.IsNullOrWhiteSpace(textBox21.Text.Trim()) ? "''" : $"'{textBox21.Text}'";
                string pGeburtsdatum = dateTimePicker2.Value.ToString("yyyy-MM-dd");
                string pGeschlecht = comboBox3.SelectedItem == null ? "NULL" : $"'{comboBox3.SelectedItem}'";
                string pGröße = string.IsNullOrWhiteSpace(textBox22.Text.Trim()) ? "NULL" : textBox22.Text;
                string pGewicht = string.IsNullOrWhiteSpace(textBox23.Text.Trim()) ? "NULL" : textBox23.Text;
                string pBlutgruppe = string.IsNullOrWhiteSpace(textBox24.Text.Trim()) ? "''" : $"'{textBox24.Text}'";
                string pTelefon = string.IsNullOrWhiteSpace(textBox25.Text.Trim()) ? "NULL" : textBox25.Text;
                string pHandy = string.IsNullOrWhiteSpace(textBox26.Text.Trim()) ? "NULL" : textBox26.Text;
                string pEmail = string.IsNullOrWhiteSpace(textBox27.Text.Trim()) ? "''" : $"'{textBox27.Text}'";
                string pStraße = string.IsNullOrWhiteSpace(textBox28.Text.Trim()) ? "''" : $"'{textBox28.Text}'";
                string pHausnummer = string.IsNullOrWhiteSpace(textBox29.Text.Trim()) ? "NULL" : textBox29.Text;
                string pPLZ = string.IsNullOrWhiteSpace(textBox30.Text.Trim()) ? "NULL" : textBox30.Text;
                string pStadt = string.IsNullOrWhiteSpace(textBox31.Text.Trim()) ? "''" : $"'{textBox31.Text}'";
                string pLand = string.IsNullOrWhiteSpace(textBox32.Text.Trim()) ? "''" : $"'{textBox32.Text}'";
                string pIBAN = string.IsNullOrWhiteSpace(textBox33.Text.Trim()) ? "NULL" : textBox33.Text;
                string pKV_ID = comboBox4.SelectedItem == null ? "NULL" : comboBox4.SelectedItem.ToString();
                string pVersichertennummer = string.IsNullOrWhiteSpace(textBox35.Text.Trim()) ? "NULL" : textBox35.Text;

                // SQL-Befehl erstellen
                cmd.CommandText = "INSERT INTO Patient (P_ID, P_Name, P_Vorname, P_Geburtsdatum, P_Geschlecht, P_Größe, P_Gewicht, P_Blutgruppe, P_Telefon, " +
                                  "P_Handy, P_Email, P_Straße, P_Hausnummer, P_PLZ, P_Stadt, P_Land, P_IBAN, P_KV_ID, P_Versichertennummer) " +
                                  "VALUES (" +
                                  $"{pID}, {pName}, {pVorname}, '{pGeburtsdatum}', {pGeschlecht}, {pGröße}, {pGewicht}, {pBlutgruppe}, {pTelefon}, " +
                                  $"{pHandy}, {pEmail}, {pStraße}, {pHausnummer}, {pPLZ}, {pStadt}, {pLand}, {pIBAN}, {pKV_ID}, {pVersichertennummer})";

                cmd.ExecuteNonQuery();

                MessageBox.Show("Sie haben einen neuen Patienten hinzugefügt", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Neue Zahl bei ID
                Auto();

                // Textboxen leeren
                textBox19.Clear();
                textBox20.Clear();
                textBox21.Clear();
                comboBox3.SelectedIndex = -1;
                textBox22.Clear();
                textBox23.Clear();
                textBox24.Clear();
                textBox25.Clear();
                textBox26.Clear();
                textBox27.Clear();
                textBox28.Clear();
                textBox29.Clear();
                textBox30.Clear();
                textBox31.Clear();
                textBox32.Clear();
                textBox33.Clear();
                textBox35.Clear();
                comboBox4.SelectedIndex = -1;

                // Datagrid updaten
                datafill();

                //autowert

                Auto();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ungültige Eingabewerte! Bitte überprüfen Sie ob Sie bei den Zahlfeldern keinen Text eingetragen haben ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }

        void Auto()
        {
            try
            {
                cmd.CommandText = "select max(P_ID)+1 from Patient";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox19.Text = dr.GetInt32(0).ToString();

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

      

        private void AbbrechenPatient_Click(object sender, EventArgs e)
        {

            textBox20.Clear();
            textBox21.Clear();
            comboBox3.SelectedIndex = 0;
            textBox22.Clear();
            textBox23.Clear();
            textBox24.Clear();
            textBox25.Clear();
            textBox26.Clear();
            textBox27.Clear();
            textBox28.Clear();
            textBox29.Clear();
            textBox30.Clear();
            textBox31.Clear();
            textBox32.Clear();
            textBox33.Clear();
            comboBox1.SelectedIndex = 0;

            Hinzufuege.Visible = false;


        }

        private void Allergie_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Damit es nicht zu einem fehler beim öffnen der Befunde gibt
            if (string.IsNullOrEmpty(label57.Text))
            {
                MessageBox.Show("bitte wählen Sie einen Patienten aus!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Befundepanel.Visible == false)
            {
                Befundepanel.Visible = true;
                Hinzufuege.Visible = false;
                Allergiepanel.Visible = false;


            }
            else
            {
                Befundepanel.Visible = false;
            }

        }





        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Updatebefund_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "UPDATE Befund SET BE_Befund = '" + richTextBox1.Text + "', BE_Behandlung = '" + richTextBox2.Text + "', BE_Datum = '" + dateTimePicker3.Value + "', BE_Medikamentengabe = '" + textBox37.Text + "' WHERE BE_ID = " + textBox36.Text;

                cmd.ExecuteNonQuery();
                MessageBox.Show("Dieser Befund wurde geupdatet", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BEFUNDELISTBOX();


            }
            catch (Exception a)
            {

                MessageBox.Show("g" + a);
            }
        }

        private void befunddelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Wollen Sie wirklich diesen Befund Löschen? Es gehen alle bereits eingegebenen Daten verloren!", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    cmd.CommandText = "delete from Befund WHERE BE_ID = " + textBox36.Text;
                    cmd.ExecuteNonQuery();

                    BEFUNDELISTBOX();


                }



            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }
        }

        private void befundinsert_Click(object sender, EventArgs e)
        {
            textBox36.Clear();
            AUTOBEFUND();

            richTextBox1.Clear();
            richTextBox2.Clear();
            dateTimePicker1.Value = DateTime.Today;
            textBox37.Clear();

            button9.Visible = true;



        }

        void AUTOBEFUND()
        {
            try
            {
                cmd.CommandText = "select max(BE_ID)+1 from Befund";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox36.Text = dr.GetInt32(0).ToString();

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox36.Text) || string.IsNullOrEmpty(richTextBox1.Text) || string.IsNullOrEmpty(richTextBox2.Text))
                {
                    MessageBox.Show("Bitte füllen Sie die Pflichtfelder aus!", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (dateTimePicker3.Value > DateTime.Today)
                {
                    MessageBox.Show("Bitte geben Sie ein gültiges Datum ein", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }



                dr.Close();
                cmd.CommandText = "INSERT INTO Befund (BE_ID, BE_Befund, BE_Behandlung, BE_Datum, BE_Medikamentengabe, BE_P_ID) values (" + textBox36.Text + ", '" + richTextBox1.Text + "', '" + richTextBox2.Text + "', '" + dateTimePicker3.Value + "' , '" + textBox37.Text + "' , " + label57.Text + ")";
                cmd.ExecuteNonQuery();
                MessageBox.Show("Sie haben einen neuen Befund angelegt", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BEFUNDELISTBOX();
                dr.Close();

                textBox36.Clear();
                richTextBox1.Clear();
                richTextBox2.Clear();
                dateTimePicker1.Value = DateTime.Today;
                textBox37.Clear();

                button9.Visible = false;


            }
            catch (Exception a)
            {

                MessageBox.Show("Test" + a);
            }
        }

        void BEFUNDELISTBOX()
        {
            try
            {
                cmd.CommandText = "SELECT BE_ID, BE_Befund FROM Befund WHERE BE_P_ID = " + label57.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox3.Items.Clear();

                while (dr.Read())
                {

                    // Kombiniere BE_ID und BE_Befund in einer Zeile
                    string item = dr.GetInt32(0).ToString() + " - " + dr.GetString(1);
                    listBox3.Items.Add(item);

                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Bitte klicken Sie auf die ID des Patienten", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ;
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {


            try
            {
                // Sicherstellen, dass ein Element in der ListBox ausgewählt ist
                if (listBox3.SelectedItem != null)
                {
                    // Hole den ausgewählten Text aus der ListBox
                    string selectedItem = listBox3.SelectedItem.ToString();

                    // Splitte den String nach dem " - "
                    string[] parts = selectedItem.Split(new string[] { " - " }, StringSplitOptions.None);

                    // Extrahiere die BE_ID (der erste Teil des gesplitteten Strings)
                    string idString = parts[0];


                    // Umwandeln der ID in eine Integer
                    int selectedID = int.Parse(idString);

                    // Jetzt kannst du die ID weiter verwenden, z. B. für eine SQL-Abfrage
                    cmd.CommandText = "SELECT BE_ID, BE_Befund, BE_Datum, BE_Behandlung, BE_Medikamentengabe FROM Befund WHERE BE_ID = " + selectedID;
                    dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        // Fülle die TextBoxen oder RichTextBoxen mit den abgerufenen Daten
                        textBox36.Text = dr.GetInt32(0).ToString();       // BE_ID
                        richTextBox1.Text = dr.GetString(1);              // BE_Befund
                        richTextBox2.Text = dr.GetString(3);              // BE_Behandlung
                        dateTimePicker3.Value = dr.GetDateTime(2);        // BE_Datum
                        textBox37.Text = dr.GetString(4);                 // BE_Medikamentengabe
                    }

                    dr.Close();
                }
                else
                {
                    MessageBox.Show("Bitte wählen Sie einen Befund aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler beim Laden des Befundes: " + a.Message, "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }




        }

        private void button8_Click(object sender, EventArgs e)
        {
            Befundepanel.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Bitte wählen Sie einen Patienten aus!", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            Form R = new Roentgen(System.Convert.ToInt32(textBox2.Text), System.Convert.ToString(textBox3.Text.Trim()), textBox4.Text.Trim());
            R.ShowDialog();
        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        void ALLERGIENLISTBOX()
        {
            try
            {
                cmd.CommandText = "Select P_AL_Id, Al_Bezeichnung from Allergie, Patient_Allergie WHERE P_AL_ID = Al_ID and Pa_P_ID = " + label54.Text;
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox6.Items.Clear();

                while (dr.Read())
                {
                    string item = dr.GetInt32(0).ToString() + " - " + dr.GetString(1);
                    listBox6.Items.Add(item);
                }

                dr.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Test" + a);

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            //Damit es nicht zu einem fehler beim öffnen der Allergie gibt
            if (string.IsNullOrEmpty(label54.Text))
            {
                MessageBox.Show("bitte wählen Sie einen Patienten aus!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Allergiepanel.Visible == false)
            {
                Allergiepanel.Visible = true;
                Hinzufuege.Visible = false;
                Befundepanel.Visible = false;


                ALLERGIENLISTBOX();

            }
            else
            {
                Allergiepanel.Visible = false;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void listBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form Allergien = new Allergie(System.Convert.ToInt32(label54.Text), System.Convert.ToString(label55.Text));
            Allergien.ShowDialog();

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void label33_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label57_Click(object sender, EventArgs e)
        {

        }

        private void label57_Click_1(object sender, EventArgs e)
        {

        }

        private void Befundepanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label55_Click(object sender, EventArgs e)
        {

        }

        private void textBox34_TextChanged(object sender, EventArgs e)
        {
            textBox36.Clear();
            textBox37.Clear();

            richTextBox1.Clear();
            richTextBox2.Clear();

            dateTimePicker3.Value = DateTime.Today;

        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            Allergiepanel.Visible = false;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label58_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form HP = new Form2(null);
            this.Hide();
            HP.ShowDialog();
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace MedicalSoft
{
    public partial class Leistungen : Form
    {

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        DataSet ds = new DataSet();
        OleDbDataAdapter da = new OleDbDataAdapter();
        OleDbDataReader dr = null;
        DataTable dt = new DataTable();


        public Leistungen()
        {
            InitializeComponent();

            textBox2.ReadOnly = true;
            panel1.Visible = false;
            textBox7.ReadOnly = true;
        }

        private void Leistungen_Load(object sender, EventArgs e)
        {

            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }

            dataLfill();

            filllistbox();

            autowert();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        void dataLfill()
        {
            try
            {
                try
                {


                    cmd.CommandText = "Select L_ID, L_Bezeichnung, L_Beschreibung, L_Pauschale, L_EBM_Code, L_OPS_Code from Leistung where L_Gelöscht = false";
                    cmd.Connection = con;

                    da.SelectCommand = cmd;

                    dt.Clear();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;


                    dataGridView1.Columns[0].HeaderCell.Value = "Nummer";
                    dataGridView1.Columns[1].HeaderCell.Value = "Bezeichnung";
                    dataGridView1.Columns[2].HeaderCell.Value = "Beschreibung";
                    dataGridView1.Columns[3].HeaderCell.Value = "Pauschale";
                    dataGridView1.Columns[4].HeaderCell.Value = "EBM Code";
                    dataGridView1.Columns[5].HeaderCell.Value = "OPS Code";








                }
                catch (Exception a)
                {
                    MessageBox.Show("Fehler" + a);
                }

            }
            catch (Exception a)
            {



            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form H = new Form2(System.Convert.ToString(textBox1.Text));
            this.Hide();
            H.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                if (MessageBox.Show("Wollen Sie die Leistung wirklich verändern?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {


                    if (!double.TryParse(textBox4.Text, out double lPauschale) || !int.TryParse(textBox6.Text, out int OPS) || !int.TryParse(textBox5.Text, out int EBM))
                    {
                        MessageBox.Show("Ungültiger Wert in den Eingabefeldern", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    cmd.CommandText = "update Leistung set L_Bezeichnung = '" + textBox3.Text + "' , L_Beschreibung = '" + richTextBox1.Text + "' , L_Pauschale = " + lPauschale + " , L_EBM_Code = " + EBM + " , L_OPS_Code = " + OPS + " where L_ID = " + textBox2.Text;
                    cmd.ExecuteNonQuery();


                    cmd.CommandText = "update interne_Leistung set IL_Bezeichnung = '" + textBox3.Text + "' , IL_Preis = " + lPauschale + " where IL_ID = " + textBox2.Text;
                    cmd.ExecuteNonQuery();  


                    // Daten neu laden
                    dataLfill();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bitte klicken Sie ein Feld im Datagridview an " , "Vorsicht", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count < 1)
            {
                MessageBox.Show("Bitte klicken Sie links auf die ganze Zeile ");

            }
            else
            {


                try
                {



                    string Nummer = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();

                    string Bezeichnung = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();

                    string Beschreibung = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();

                    string Pauschale = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();

                    string EBM = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();

                    string OPS = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();






                    textBox2.Text = Nummer;
                    textBox3.Text = Bezeichnung;
                    richTextBox1.Text = Beschreibung;
                    textBox4.Text = Pauschale;
                    textBox5.Text = EBM;
                    textBox6.Text = OPS;







                }
                catch (Exception a)
                {

                    MessageBox.Show("Fehler " + a);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (panel1.Visible == false)
            {
                panel1.Visible = true;
            }
            else
            {
                panel1.Visible = false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                cmd.CommandText = "update Leistung set L_Gelöscht = true where L_ID = " + textBox2.Text;
                cmd.ExecuteNonQuery();

                dataLfill();

                filllistbox();

                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();
                richTextBox1.Clear();
            }
            catch (Exception a)
            {

                MessageBox.Show("Bitte Clicken Sie ein Feld an um den Mitarbeiter zu Löschen", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        void filllistbox()
        {
            try
            {
                cmd.CommandText = "select L_ID from Leistung where L_Gelöscht = true";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                listBox1.Items.Clear();

                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetInt32(0));
                }

                dr.Close();


            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                

                if (MessageBox.Show("Wollen Sie den Mitarbeiter wirklich Rückgängig machen ?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    cmd.CommandText = "update Leistung set L_Gelöscht = false where L_ID = " + listBox1.SelectedItem;
                    cmd.ExecuteNonQuery();
                }

                dataLfill();

                filllistbox();

            }
            catch (Exception a)
            {

                MessageBox.Show("Sie müssen einen Mitarbeiter auswählen um Ihn rückgänig zu machen!" , "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Wollen Sie den Hinzufüge Vorgang wirklich abbrechen?", "Achtung", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox11.Clear();
                richTextBox2.Clear();

                panel1.Visible = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox8.Text) || string.IsNullOrEmpty(textBox9.Text) || string.IsNullOrEmpty(textBox10.Text) || string.IsNullOrEmpty(textBox11.Text) || string.IsNullOrEmpty(richTextBox2.Text))
            {
                MessageBox.Show("Bitte füllen Sie die Felder aus um einen Mitarbeiter anlegen zu können", "Achtung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    if (MessageBox.Show("Wollen Sie einen neuen Mitarbeiter Hinzufügen ? ", "Frage", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {


                        cmd.CommandText = "insert into interne_Leistung (IL_ID, IL_Bezeichnung, IL_Preis) values (" + textBox7.Text + " , '" + textBox8.Text + "' , " + textBox11.Text + ")";
                        cmd.ExecuteNonQuery();


                        cmd.CommandText = "insert into Leistung (L_ID, L_Bezeichnung, L_Beschreibung, L_Pauschale, L_EBM_Code, L_OPS_Code) values (" + textBox7.Text + " , '" + textBox8.Text + "' , '" + richTextBox2.Text + "' , " + textBox11.Text + " , " + textBox9.Text + " , " + textBox10.Text + ")";
                        cmd.ExecuteNonQuery();


                        dataLfill();

                        autowert();


                        textBox8.Clear();
                        textBox9.Clear();
                        textBox10.Clear();
                        textBox11.Clear();
                        richTextBox2.Clear();




                    }


                }
                catch (Exception a)
                {

                    MessageBox.Show("Bitte geben Sie richtig Werte ein", "Erorr", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }

        void autowert()
        {
            try
            {
                cmd.CommandText = "select max(L_ID)+1 from Leistung";
                cmd.Connection = con;
                dr = cmd.ExecuteReader();

                dr.Read();

                textBox7.Text = dr.GetInt32(0).ToString();

                dr.Close();

            }
            catch (Exception a)
            {

                MessageBox.Show("f" + a);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string suchtext = textBox1.Text.Trim();
            suchfilternL(suchtext);
        }

        void suchfilternL(string suchtext)
        {
            try
            {
                if (comboBox1.SelectedIndex == -1 || comboBox1.SelectedItem == null)
                {
                    comboBox1.SelectedIndex = 0;
                    MessageBox.Show("Bitte wählen Sie einen gültigen Wert aus der Liste aus.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                else
                {


                    string selectedColumn = comboBox1.SelectedItem.ToString();
                    DataView dv = new DataView(dt); // DataView verwenden, um den Filter anzuwenden

                    if (string.IsNullOrEmpty(suchtext))
                    {
                        // Wenn das Textfeld bzw. die TextBox leer ist, werden alle Daten wieder angezeigt
                        dv.RowFilter = string.Empty;

                    }
                    else if (!string.IsNullOrEmpty(selectedColumn))
                    {
                        // Filterung nach der ausgewählten Spalte => hier: Krankenkasse-ID
                        if (selectedColumn == "Nummer")
                        {
                            // Wenn nach der Krankenkassen-ID gesucht wird, werden nur Einträge angezeigt die mit dem Suchtext anfangen
                            dv.RowFilter = $"Convert(L_ID, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Bezeichnung")
                        {
                            dv.RowFilter = $"Convert(L_Bezeichnung, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "EBM Code")
                        {
                            dv.RowFilter = $"Convert(L_EBM_Code, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "OPS Code")
                        {
                            dv.RowFilter = $"Convert(L_OPS_Code, 'System.String') LIKE '{suchtext}%'";
                        }
                        else if (selectedColumn == "Pauschale")
                        {
                            dv.RowFilter = $"Convert(L_Pauschale, 'System.String') LIKE '{suchtext}%'";
                        }

                    }



                    // Gefiltertes DataView als Datenquelle setzen
                    dataGridView1.DataSource = dv;
                }


            }
            catch (Exception a)
            {
                MessageBox.Show("Fehler" + a);
            }
        }
    }
}

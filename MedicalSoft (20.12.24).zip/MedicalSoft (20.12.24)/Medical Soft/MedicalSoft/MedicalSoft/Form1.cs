﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace MedicalSoft
{
    public partial class Form1 : Form
    {

        OleDbConnection con = new OleDbConnection();
        OleDbCommand cmd = new OleDbCommand();
        OleDbDataReader dr = null;


        public Form1()
        {
            InitializeComponent();
            
    


        }

        private void Form1_Load(object sender, EventArgs e)
        {

            try
            {
                con.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=Database.accdb";

                con.Open();


            }
            catch (Exception a)
            {
                MessageBox.Show("Öffungsfehler der Datenbank" + a);
                this.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Bitte füllen Sie die Felder aus um sich anzumelden");
            }
            else
            {
                try
                {
                    cmd.CommandText = "Select M_Name, M_Passwort from Mitarbeiter where M_Name = '" +textBox1.Text+ "' and M_Passwort = '"+textBox2.Text+"'";
                    cmd.Connection = con;

                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                    {
                        Form H = new Form2(System.Convert.ToString(textBox1.Text));
                        this.Hide();
                        H.ShowDialog();
                        

                        textBox1.Clear();
                        textBox2.Clear();


                        

                    }
                    else
                    {
                        textBox1.Clear();
                        textBox2.Clear();

                        MessageBox.Show(" Dieser Benutzer existiert nicht, bitte versuchen Sie es erneut");

                    }

                    dr.Close();


                }
                catch (Exception a)
                {
                    
                    MessageBox.Show(" Dieser Benutzer existiert nicht, bitte versuchen Sie es erneut");


                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (textBox2.UseSystemPasswordChar == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            if (textBox2.UseSystemPasswordChar == true)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }
    }
}
